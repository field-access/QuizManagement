# Experimental AI quiz generation

Parked locally on 2026-10-30. These files are ignored by Git and Vercel and are not built or served.

The api/, css/, js/, views/, lib/ and model catalog retain the implementation. scripts/dev.mjs is the prior AI-enabled server. integration/ contains the matching active files before removal, including navigation and build wiring. This archive is for deliberate future restoration; it is not a standalone running app. Restore sources and reintroduce the Generate integrations selectively so newer study and storage changes are preserved.
