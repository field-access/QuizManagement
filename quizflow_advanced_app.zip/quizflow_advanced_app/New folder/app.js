const K={sessions:"examflow_sessions_v2",results:"examflow_results_v2",goal:"examflow_goal_v2",plans:"examflow_plans_v2",settings:"examflow_settings_v2",exams:"examflow_exams_v1",recent:"examflow_recent_quizzes_v1",study:"examflow_study_activity_v1"};
const sampleQuestions=[
{text:"Which algorithm guarantees shortest paths from a source when edge weights are non-negative?",options:["DFS","Dijkstra's algorithm"],answer:"B",marks:2,negativeMarks:.5},
{text:"What is the average-case lookup complexity of a good hash table?",options:["$O(1)$","$O(\\log n)$"],answer:"A"},
{text:"Which data structure naturally implements BFS?",options:["Queue","Stack"],answer:"A"}
];
let questions=[],answers=[],reviews=new Set(),checkedQuestions=new Set(),current=0,seconds=5*60,quizDurationMinutes=5,mode="exam",sessionId=null,examName="No quiz loaded",sections=[];
let examFinished=false;
let examId=null;
let timerState={examSeconds:5*60,practiceSeconds:5*60,running:false};
function clampDurationMinutes(value,fallback=5){
  const minutes=Number(value);
  return Number.isFinite(minutes)?Math.min(60,Math.max(1,minutes)):fallback;
}
let matchOrders={};
let settings=loadSettings();
restoreFromPersistentStorage().then(()=>{
  try{
    settings=loadSettings();
    renderSessions();
    renderDashboard();
    renderPlans();
    renderHome();
  }catch(e){}
}).finally(()=>requestPersistentStorage());

function get(k,d){try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))}catch(e){return d}}
function put(k,v){
  try{localStorage.setItem(k,JSON.stringify(v))}catch(e){
    // localStorage is intentionally kept as the fast cache; large data is backed up below.
  }
  schedulePersistentBackup();
}
/* Persistent data backup: IndexedDB is substantially larger than localStorage.
   localStorage remains the fast synchronous cache, while IndexedDB protects
   quizzes/results/sessions if the browser evicts or fills the cache. */
const EXAMFLOW_DB_NAME="ExamFlowPersistentBackup_v1",EXAMFLOW_DB_VERSION=1;
let examflowBackupTimer=null;
function openExamFlowDB(){return new Promise((resolve,reject)=>{
  if(!window.indexedDB)return reject(new Error("IndexedDB unavailable"));
  const req=indexedDB.open(EXAMFLOW_DB_NAME,EXAMFLOW_DB_VERSION);
  req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains("backup"))req.result.createObjectStore("backup")};
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
})}
function schedulePersistentBackup(){
  clearTimeout(examflowBackupTimer);
  examflowBackupTimer=setTimeout(savePersistentBackup,250);
}
async function savePersistentBackup(){
  try{
    const db=await openExamFlowDB();
    const data={};
    Object.values(K).forEach(k=>{try{const v=localStorage.getItem(k);if(v!==null)data[k]=JSON.parse(v)}catch(e){}});
    data.examDeadline=localStorage.getItem("examflow_exam_deadline")||null;
    await new Promise((resolve,reject)=>{
      const tx=db.transaction("backup","readwrite");tx.objectStore("backup").put({data,savedAt:new Date().toISOString()},"latest");
      tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(e){}
}
async function restorePersistentBackup(){
  try{
    const db=await openExamFlowDB();
    const record=await new Promise((resolve,reject)=>{
      const tx=db.transaction("backup","readonly"),req=tx.objectStore("backup").get("latest");
      req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
    });
    db.close();
    if(!record?.data)return false;
    let restored=false;
    Object.entries(record.data).forEach(([k,v])=>{
      if(Object.values(K).includes(k)){
        if(localStorage.getItem(k)===null){try{localStorage.setItem(k,JSON.stringify(v));restored=true}catch(e){}}
      }
    });
    if(record.data.examDeadline && !localStorage.getItem("examflow_exam_deadline")){
      try{localStorage.setItem("examflow_exam_deadline",record.data.examDeadline);restored=true}catch(e){}
    }
    if(restored){
      try{renderSessions();renderDashboard();renderPlans();renderHome();renderTodos();}catch(e){}
    }
    return restored;
  }catch(e){return false}
}
async function enablePersistentStorage(){
  try{if(navigator.storage?.persist)await navigator.storage.persist()}catch(e){}
}
function initPersistentBackup(){
  enablePersistentStorage();
  restorePersistentBackup();
  setTimeout(savePersistentBackup,500);
}
function id(){return Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8)}

function cloneData(value){try{return JSON.parse(JSON.stringify(value))}catch(e){return value}}
function saveExamRecord(record){
  if(!record?.id)return;
  const exams=get(K.exams,[]),next={...record,questions:cloneData(record.questions||[]),updatedAt:new Date().toISOString()};
  const old=exams.find(x=>x.id===record.id);
  if(old)Object.assign(old,next);else exams.unshift(next);
  put(K.exams,exams);
}
function registerRecentQuiz(record,metadata={}){
  if(!record?.id)return;
  const recent=get(K.recent,[]),now=new Date().toISOString();
  const old=recent.find(x=>x.id===record.id);
  const next={id:record.id,name:metadata.name||record.name||"Untitled quiz",lastOpenedAt:now,createdAt:old?.createdAt||now,plannedDate:metadata.plannedDate||old?.plannedDate||"",plannedTime:metadata.plannedTime||old?.plannedTime||"",source:metadata.source||old?.source||"quiz"};
  if(old)Object.assign(old,next);else recent.unshift(next);
  recent.sort((a,b)=>String(b.lastOpenedAt||"").localeCompare(String(a.lastOpenedAt||"")));
  put(K.recent,recent);
}
function getExamRecord(idValue){return get(K.exams,[]).find(x=>x.id===idValue)||null}
function registerActiveExam(metadata={}){
  if(!examId)examId=id();
  saveExamRecord({id:examId,name:examName,questions,sections,durationMinutes:quizDurationMinutes});
  registerRecentQuiz({id:examId,name:examName},{...metadata,name:metadata.name||examName});
}
function renderRecentQuizzes(){
  const el=document.getElementById("recentQuizzesList");if(!el)return;
  const recent=get(K.recent,[]),exams=get(K.exams,[]);
  el.innerHTML=renderStackedRows(recent,item=>{
    const exam=exams.find(x=>x.id===item.id),count=exam?.questions?.length||0;
    return `<div class="resultrow recent-quiz-row"><div class="resultmain"><strong>${esc(item.name)}</strong><small>${count} question${count===1?"":"s"}${item.plannedDate?` · Planned ${esc(item.plannedDate)}`:""} · Opened ${new Date(item.lastOpenedAt).toLocaleString()}</small></div><button class="btn" onclick="openRecentQuiz('${item.id}')">Open</button></div>`;
  },"Open a quiz to build your recent list.");
}
function openRecentQuiz(idValue){
  // Resume only unfinished work. A completed session should start a fresh attempt
  // instead of reopening the locked exam canvas.
  const session=get(K.sessions,[]).find(x=>x.examId===idValue&&!x.examFinished);
  if(session){restoreSession(session.id);return}
  const exam=getExamRecord(idValue);if(!exam)return;
  examId=exam.id;examName=exam.name;questions=cloneData(exam.questions||[]);sections=cloneData(exam.sections||[]);answers=Array(questions.length).fill(null);reviews=new Set();checkedQuestions=new Set();matchOrders={};current=0;quizDurationMinutes=clampDurationMinutes(exam.durationMinutes,settings.defaultDuration||5);seconds=quizDurationMinutes*60;timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;examFinished=false;registerRecentQuiz(exam);showView("exam");render();saveSession();
}

function renderTodos() {
  const container = document.getElementById("todoListContainer");
  if(!container) return;
  const todos = get("examflow_todos_v1", []);
  if(!todos.length) {
    container.innerHTML = "<div class='empty'>No todos yet. Add one above!</div>";
    return;
  }
  container.innerHTML = todos.map((t, i) => `
    <div style="display:flex; justify-content:space-between; align-items:center; padding: 10px; border: 1px solid var(--line); border-radius: 8px; background: ${t.done ? 'var(--surface2)' : 'var(--surface)'};">
      <div style="display:flex; align-items:center; gap: 10px; ${t.done ? 'text-decoration:line-through; opacity: 0.6;' : ''}">
        <input type="checkbox" ${t.done ? 'checked' : ''} onchange="toggleTodo(${i})" style="accent-color: var(--primary); width:16px; height:16px; cursor:pointer;">
        <div>
          <strong>${esc(t.text)}</strong>
          ${t.deadline ? `<small style="display:block; color:var(--muted); font-size:10px;">Deadline: ${esc(t.deadline)}</small>` : ''}
        </div>
      </div>
      <button class="session-delete" onclick="deleteTodo(${i})">×</button>
    </div>
  `).join("");
}

function addTodo() {
  const input = document.getElementById("todoInput");
  const deadlineInput = document.getElementById("todoDeadline");
  if(!input || !input.value.trim()) return;
  const todos = get("examflow_todos_v1", []);
  todos.push({ text: input.value.trim(), deadline: deadlineInput ? deadlineInput.value : "", done: false });
  put("examflow_todos_v1", todos);
  input.value = "";
  if(deadlineInput) deadlineInput.value = "";
  renderTodos();
}

function toggleTodo(i) {
  const todos = get("examflow_todos_v1", []);
  if(todos[i]) {
    todos[i].done = !todos[i].done;
    put("examflow_todos_v1", todos);
    renderTodos();
  }
}

function deleteTodo(i) {
  const todos = get("examflow_todos_v1", []);
  if(todos[i]) {
    todos.splice(i, 1);
    put("examflow_todos_v1", todos);
    renderTodos();
  }
}

const PLANNER_DATES_KEY="examflow_planner_dates_v1";
let plannerCalendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1);
let plannerSelectedDate="";
function plannerDateKey(date){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`}
function getPlannerDates(){
  const dates=get(PLANNER_DATES_KEY,{});
  return dates&&typeof dates==="object"&&!Array.isArray(dates)?dates:{};
}
function selectPlannerDate(value){
  if(!value)return;
  plannerSelectedDate=value;
  const date=new Date(`${value}T00:00:00`);
  plannerCalendarMonth=new Date(date.getFullYear(),date.getMonth(),1);
  const input=document.getElementById("plannerDateInput");if(input)input.value=value;
  const saved=getPlannerDates()[value];
  const label=document.getElementById("plannerDateLabel");if(label)label.value=saved?.label||"";
  renderPlannerCalendar();
}
function renderPlannerCalendar(){
  const root=document.getElementById("plannerCalendar");if(!root)return;
  if(!(plannerCalendarMonth instanceof Date)||Number.isNaN(plannerCalendarMonth.getTime())){
    plannerCalendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1);
  }
  const year=plannerCalendarMonth.getFullYear(),month=plannerCalendarMonth.getMonth();
  const title=document.getElementById("plannerCalendarTitle");
  if(title)title.textContent=plannerCalendarMonth.toLocaleDateString(undefined,{month:"long",year:"numeric"});
  const dates=getPlannerDates(),first=new Date(year,month,1),days=new Date(year,month+1,0).getDate();
  let html=["<div class='calendar-weekdays'>","<span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>","</div><div class='calendar-days'>"];
  const offset=(first.getDay()+6)%7;
  for(let i=0;i<offset;i++)html.push("<span class='calendar-day is-empty'></span>");
  const today=plannerDateKey(new Date()),exam=getSavedExamDeadline();
  for(let day=1;day<=days;day++){
    const value=plannerDateKey(new Date(year,month,day)),item=dates[value],classes=["calendar-day"];
    if(value===today)classes.push("today");
    if(value===plannerSelectedDate)classes.push("selected");
    if(value===exam)classes.push("exam");
    if(item?.type==="important")classes.push("important");
    html.push(`<button type="button" class="${classes.join(" ")}" onclick="selectPlannerDate('${value}')" title="${esc(item?.label||"Select date")}"><span>${day}</span>${item||value===exam?`<i></i>`:""}</button>`);
  }
  html.push("</div>");
  root.innerHTML=html.join("");
  if(!plannerSelectedDate){
    const input=document.getElementById("plannerDateInput");if(input)input.value="";
  }
}
function shiftPlannerCalendar(delta){
  plannerCalendarMonth=new Date(plannerCalendarMonth.getFullYear(),plannerCalendarMonth.getMonth()+delta,1);
  renderPlannerCalendar();
}
function savePlannerDate(type){
  const input=document.getElementById("plannerDateInput"),value=input?.value||plannerSelectedDate;
  if(!value){toast("Select a calendar date first");return}
  const label=document.getElementById("plannerDateLabel")?.value.trim()|| (type==="exam"?"Final exam":"Important study date");
  if(type==="exam"){
    localStorage.setItem("examflow_exam_deadline",value);
  }else{
    const dates=getPlannerDates();dates[value]={type:"important",label};put(PLANNER_DATES_KEY,dates);
  }
  plannerSelectedDate=value;renderPlannerCalendar();renderExamDeadline();toast(type==="exam"?"Exam date saved ✓":"Important date saved ✓");
}
function removePlannerDate(){
  const value=document.getElementById("plannerDateInput")?.value||plannerSelectedDate;
  if(!value)return;
  const dates=getPlannerDates();delete dates[value];put(PLANNER_DATES_KEY,dates);
  if(getSavedExamDeadline()===value)localStorage.removeItem("examflow_exam_deadline");
  renderPlannerCalendar();renderExamDeadline();toast("Calendar date removed");
}
function renderPlannerTodos(){
  const container=document.getElementById("plannerTodoList");if(!container)return;
  const todos=get("examflow_todos_v1",[]);
  container.innerHTML=todos.length?todos.map((t,i)=>`<div class="planner-todo-row${t.done?" done":""}"><label><input type="checkbox" ${t.done?"checked":""} onchange="toggleTodo(${i});renderPlannerTodos()"><span>${esc(t.text)}</span></label>${t.deadline?`<small>${esc(t.deadline)}</small>`:""}<button type="button" onclick="deleteTodo(${i});renderPlannerTodos()" aria-label="Delete task">×</button></div>`).join(""):"<div class='empty'>No study tasks yet.</div>";
}
function addPlannerTodo(){
  const input=document.getElementById("plannerTodoInput"),deadline=document.getElementById("plannerTodoDeadline");
  if(!input?.value.trim())return;
  const todos=get("examflow_todos_v1",[]);todos.push({text:input.value.trim(),deadline:deadline?.value||"",done:false});put("examflow_todos_v1",todos);
  input.value="";if(deadline)deadline.value="";renderPlannerTodos();renderTodos();
}

function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

/* EXAMFLOW_PERSISTENT_BACKUP_START */
const EXAMFLOW_BACKUP_DB="examflow_persistent_backup_v1";
const EXAMFLOW_BACKUP_STORE="app_state";

function backupPayload(){
  const data={};
  Object.values(K).forEach(key=>{
    try{
      const raw=localStorage.getItem(key);
      if(raw!==null)data[key]=JSON.parse(raw);
    }catch(e){}
  });
  try{
    const deadline=localStorage.getItem("examflow_exam_deadline");
    if(deadline!==null)data.examflow_exam_deadline=deadline;
  }catch(e){}
  return data;
}

function openBackupDB(){
  return new Promise((resolve,reject)=>{
    if(!window.indexedDB)return reject(new Error("IndexedDB unavailable"));
    const req=indexedDB.open(EXAMFLOW_BACKUP_DB,1);
    req.onupgradeneeded=()=>{
      if(!req.result.objectStoreNames.contains(EXAMFLOW_BACKUP_STORE)){
        req.result.createObjectStore(EXAMFLOW_BACKUP_STORE);
      }
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}

async function backupToPersistentStorage(){
  try{
    const db=await openBackupDB();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(EXAMFLOW_BACKUP_STORE,"readwrite");
      tx.objectStore(EXAMFLOW_BACKUP_STORE).put({
        savedAt:new Date().toISOString(),
        data:backupPayload()
      },"latest");
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(e){}
}

async function restoreFromPersistentStorage(){
  try{
    const db=await openBackupDB();
    const snapshot=await new Promise((resolve,reject)=>{
      const tx=db.transaction(EXAMFLOW_BACKUP_STORE,"readonly");
      const req=tx.objectStore(EXAMFLOW_BACKUP_STORE).get("latest");
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error);
    });
    db.close();
    if(!snapshot || !snapshot.data)return;

    // Only restore missing keys; never overwrite newer localStorage data.
    Object.entries(snapshot.data).forEach(([key,value])=>{
      if(localStorage.getItem(key)===null){
        try{
          localStorage.setItem(key,typeof value==="string"?value:JSON.stringify(value));
        }catch(e){}
      }
    });

    try{
      if(localStorage.getItem("examflow_exam_deadline")===null &&
         snapshot.data.examflow_exam_deadline!==undefined){
        localStorage.setItem("examflow_exam_deadline",snapshot.data.examflow_exam_deadline);
      }
    }catch(e){}
  }catch(e){}
}

async function requestPersistentStorage(){
  try{
    if(navigator.storage && navigator.storage.persist){
      await navigator.storage.persist();
    }
  }catch(e){}
}
/* EXAMFLOW_PERSISTENT_BACKUP_END */

function loadSettings(){
 const s=Object.assign({theme:"light",defaultMode:"exam",fontFamily:"DM Sans",questionTextSize:"standard",colorScheme:"classic",soundEnabled:true,examCardWidth:"balanced",instantFeedback:false,defaultDuration:5},get(K.settings,{}));
 delete s.defaultMarks;
 delete s.defaultNegative;
 if(s.fontFamily==="IBM Plex Mono")s.fontFamily="DM Sans";
 if(!["small","standard","large","extra-large"].includes(s.questionTextSize))s.questionTextSize="standard";
 s.defaultDuration=[5,10,15,20,30,45,60].includes(Number(s.defaultDuration))?Number(s.defaultDuration):5;
 return s;
}
function saveSettings(){
  const feedbackToggle=document.getElementById("instantFeedback");
  if(feedbackToggle)settings.instantFeedback=feedbackToggle.checked;
  const duration=document.getElementById("defaultDuration");
  if(duration)settings.defaultDuration=[5,10,15,20,30,45,60].includes(Number(duration.value))?Number(duration.value):5;
  const fs=document.getElementById("fontSelect");if(fs)settings.fontFamily=fs.value;
  const textSize=document.getElementById("questionTextSizeSelect");if(textSize)settings.questionTextSize=textSize.value;
  const cs=document.getElementById("colorSchemeSelect");if(cs)settings.colorScheme=cs.value;
  const cw=document.getElementById("examCardWidthSelect");if(cw)settings.examCardWidth=cw.value;
  put(K.settings,settings);applySettings();
}
function applySettings(){
 settings.defaultDuration=[5,10,15,20,30,45,60].includes(Number(settings.defaultDuration))?Number(settings.defaultDuration):5;
 document.body.classList.toggle("dark",settings.theme==="dark");updateTheme();
 const d=document.getElementById("defaultDuration");if(d)d.value=String(settings.defaultDuration);
 const fs=document.getElementById("fontSelect");if(fs)fs.value=settings.fontFamily||"DM Sans";
 const textSizes=["small","standard","large","extra-large"];
 const textSize=textSizes.includes(settings.questionTextSize)?settings.questionTextSize:"standard";
 settings.questionTextSize=textSize;
 document.body.classList.remove(...textSizes.map(x=>`question-text-${x}`));
 document.body.classList.add(`question-text-${textSize}`);
 const textSizeSelect=document.getElementById("questionTextSizeSelect");if(textSizeSelect)textSizeSelect.value=textSize;
 const schemes=["classic","ocean","forest","sunset","slate"];
 document.body.classList.remove(...schemes.map(x=>`scheme-${x}`));
 const scheme=schemes.includes(settings.colorScheme)?settings.colorScheme:"classic";
 settings.colorScheme=scheme;
 document.body.classList.add(`scheme-${scheme}`);
 const cs=document.getElementById("colorSchemeSelect");if(cs)cs.value=scheme;
 const widths=["compact","balanced","spacious"];
 const width=widths.includes(settings.examCardWidth)?settings.examCardWidth:"balanced";
 settings.examCardWidth=width;
 document.body.classList.remove(...widths.map(x=>`exam-card-${x}`));
 document.body.classList.add(`exam-card-${width}`);
 const cw=document.getElementById("examCardWidthSelect");if(cw)cw.value=width;
 const soundOn=settings.soundEnabled!==false;
 const soundToggle=document.getElementById("soundOnBtn"),soundMute=document.getElementById("soundOffBtn");
 if(soundToggle)soundToggle.classList.toggle("active",soundOn);
 if(soundMute)soundMute.classList.toggle("active",!soundOn);
 let fstr = "'DM Sans', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="System Default") fstr = "'DM Sans', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Serif Elegant") fstr = "'Latin Modern Roman', 'Computer Modern', 'STIX Two Text', 'Times New Roman', serif";
 if(settings.fontFamily==="Modern Rounded") fstr = "'Nunito', 'Quicksand', 'Arial Rounded MT Bold', sans-serif";
 if(settings.fontFamily==="Monospace") fstr = "'Cascadia Code', 'SFMono-Regular', Consolas, monospace";
 if(settings.fontFamily==="Source Serif") fstr = "'Source Serif 4', Georgia, serif";
 if(settings.fontFamily==="Libre Baskerville") fstr = "'Libre Baskerville', Georgia, serif";
 if(settings.fontFamily==="Lora") fstr = "'Lora', Georgia, serif";
 if(settings.fontFamily==="DM Sans") fstr = "'DM Sans', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Nunito Sans") fstr = "'Nunito Sans', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Inter") fstr = "'Inter', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Roboto") fstr = "'Roboto', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Open Sans") fstr = "'Open Sans', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Manrope") fstr = "'Manrope', 'Segoe UI', sans-serif";
 if(settings.fontFamily==="Merriweather") fstr = "'Merriweather', Georgia, serif";
 if(settings.fontFamily==="IBM Plex Mono") fstr = "'IBM Plex Mono', Consolas, monospace";
 if(settings.fontFamily==="JetBrains Mono") fstr = "'JetBrains Mono', Consolas, monospace";
 if(settings.fontFamily==="Fira Code") fstr = "'Fira Code', Consolas, monospace";
 document.body.style.setProperty('--exam-font', fstr);
 mode=settings.defaultMode;updateModeUI()
}
function setTheme(x){settings.theme=x;put(K.settings,settings);applySettings()}
function setSoundEnabled(enabled){settings.soundEnabled=!!enabled;put(K.settings,settings);applySettings();toast(enabled?"Interface sounds on":"Interface sounds muted")}
function setDefaultMode(x){settings.defaultMode=x;put(K.settings,settings);setMode(x)}
function updateTheme(){document.getElementById("lightBtn").classList.toggle("active",settings.theme==="light");document.getElementById("darkBtn").classList.toggle("active",settings.theme==="dark")}
function updateTimerUI(){
 const examEl=document.getElementById("timer");
 if(examEl)examEl.textContent=formatGlobalTime(timerState.examSeconds);
 const examCtl=document.getElementById("examTimerControl");
 if(examCtl)examCtl.style.display=mode==="exam"?"flex":"none";
}
function formatGlobalTime(sec){
 sec=Math.max(0,Math.floor(Number(sec)||0));
 return `${String(Math.floor(sec/60)).padStart(2,"0")}:${String(sec%60).padStart(2,"0")}`;
}
function startGlobalTimer(){
 timerState.running=true;
 updateTimerUI();
}
function pauseGlobalTimer(){
 timerState.running=false;
 updateTimerUI();
}
function togglePracticeTimer(){
 if(mode!=="practice")return;
 if(timerState.practiceSeconds<=0)timerState.practiceSeconds=5*60;
 timerState.running=!timerState.running;
 updateTimerUI();
 saveSessionSoon();
}
function setPracticeTimer(minutes){
 minutes=Number(minutes);
 if(minutes!==5&&minutes!==10)return;
 timerState.practiceSeconds=minutes*60;
 timerState.running=true;
 mode="practice";
 updateModeUI();
 updateTimerUI();
 saveSessionSoon();
 toast("Practice timer: "+minutes+" minutes");
}
function updateModeUI(){
 document.body.classList.toggle("practice-active",mode==="practice");
 document.getElementById("examMode").classList.toggle("active",mode==="exam");
 document.getElementById("practiceMode").classList.toggle("active",mode==="practice");
 document.getElementById("defaultExam").classList.toggle("active",settings.defaultMode==="exam");
 document.getElementById("defaultPractice").classList.toggle("active",settings.defaultMode==="practice");
 if(document.getElementById("modeBadge"))document.getElementById("modeBadge").textContent=mode==="exam"?"EXAM MODE":"PRACTICE MODE";
 updateTimerUI();
}
function setMode(x){
 mode=x==="practice"?"practice":"exam";
 if(mode==="practice"){
   if(!Number.isFinite(timerState.practiceSeconds)||timerState.practiceSeconds<=0)timerState.practiceSeconds=5*60;
 }else{
   const maxExam=clampDurationMinutes(quizDurationMinutes||settings.defaultDuration||5)*60;
   if(!Number.isFinite(timerState.examSeconds)||timerState.examSeconds<=0)timerState.examSeconds=maxExam;
 }
 timerState.running=true;
 updateModeUI();
 updateTimerUI();
 render();
 saveSessionSoon();
}

function normalizeImageSource(value){
 if(typeof value==="string")return value.trim();
 if(value&&typeof value==="object")return String(value.src??value.url??value.data??"").trim();
 return "";
}
function normalize(q,defaults={}){
 const text=q.question??q.text??"";
 const type=String(q.type??q.questionType??"mcq").toLowerCase().replace(/[\s-]+/g,"_");
 const explanation=q.explanation??q.reason??q.solution??q.rationale??"";
 const hint=q.hint??"";
 const marks=Number(q.marks??q.points??defaults.marks??1);
 const negativeMarks=Number(q.negativeMarks??q.negative??defaults.negativeMarks??0);
 const section=q.section??q.category??q.topic??defaults.name??"General";
 const image=normalizeImageSource(q.image??q.picture);

 if(typeof text!=="string")throw Error("Each question needs question/text.");

 const allowed=["mcq","single_choice","true_false","fill_blank","fill_in_the_blank","match","matching","drag_drop","drag_and_drop","image","image_choice","ordering"];
 if(!allowed.includes(type))throw Error(`Unsupported question type: ${type}`);

 if(type==="fill_blank"||type==="fill_in_the_blank"){
   const accepted=q.acceptedAnswers??q.accepted??q.answers??q.answer;
   const vals=Array.isArray(accepted)?accepted.map(String):[String(accepted??"")];
   if(!vals[0])throw Error("Fill-in-the-blank needs answer/acceptedAnswers.");
   return {type:"fill_blank",text,options:[],answer:vals[0],acceptedAnswers:vals,explanation,hint,marks,negativeMarks,section,image};
 }

 if(type==="match"||type==="matching"||type==="drag_drop"||type==="drag_and_drop"){
   const pairs=q.pairs??q.matches??q.matching;
   if(!Array.isArray(pairs)||!pairs.length)throw Error("Matching questions need a pairs array.");
   const normalizedPairs=pairs.map((p,i)=>{
     if(typeof p==="object")return {left:String(p.left??p.question??p.prompt??""),right:String(p.right??p.answer??p.match??"")};
     if(Array.isArray(p))return {left:String(p[0]??""),right:String(p[1]??"")};
     throw Error(`Invalid matching pair ${i+1}.`);
   });
   if(normalizedPairs.some(p=>!p.left||!p.right))throw Error("Every matching pair needs left and right values.");
   return {type:type.includes("drag")?"drag_drop":"match",text,options:[],answer:normalizedPairs.map(p=>p.right),pairs:normalizedPairs,explanation,hint,marks,negativeMarks,section,image};
 }

 if(type==="ordering"){
   const items=q.items??q.options??q.choices;
   const raw=q.answer??q.correct;
   if(!Array.isArray(items)||items.length<2)throw Error("Ordering questions need an items array.");
   const order=Array.isArray(raw)?raw.map(String):[];
   if(order.length!==items.length)throw Error("Ordering answer must contain every item in order.");
   return {type:"ordering",text,options:items.map(String),answer:order,explanation,hint,marks,negativeMarks,section,image};
 }

 const options=q.options??q.choices;
 if(type==="true_false"){
   const opts=["True","False"];
   const raw=q.answer??q.correct;
   const answer=String(raw).toLowerCase().startsWith("t")?"A":"B";
   return {type:"true_false",text,options:opts,answer,explanation,hint,marks,negativeMarks,section,image};
 }
 if(!Array.isArray(options)||options.length<2)throw Error("Each choice question needs at least 2 options/choices.");
 const raw=q.answer??q.correct;
 let answer=null;
 if(typeof raw==="number"&&raw>=0&&raw<options.length)answer=String.fromCharCode(65+raw);
 else if(typeof raw==="string"){
   const s=raw.trim(),letter=s.match(/^([A-Z])$/i);
   if(letter){let n=letter[1].toUpperCase().charCodeAt(0)-65;if(n<options.length)answer=letter[1].toUpperCase()}
   if(!answer){let i=options.findIndex(x=>String(x).trim()===s);if(i>=0)answer=String.fromCharCode(65+i)}
 }
 if(!answer)throw Error("Could not resolve answer for: "+text.slice(0,55));
 return {type:type==="image_choice"?"image_choice":type==="image"?"image":"mcq",text,options:options.map(String),answer,explanation,hint,marks,negativeMarks,section,image};
}

function escapeInvalidJsonBackslashes(text){
 let output="",inString=false;
 for(let i=0;i<text.length;i++){
   const char=text[i];
   if(char==='"'){inString=!inString;output+=char;continue}
   if(!inString||char!=="\\"){output+=char;continue}
   const next=text[i+1];
   const latexCommand=text.slice(i+1).match(/^(?:text|times|theta|therefore|thinspace|rightarrow|right|rho|begin|beta|bigg|big|bold|bar|frac|forall|function|neq|nabla|not|nu)(?![A-Za-z])/);
   if(latexCommand){output+="\\\\"+latexCommand[0];i+=latexCommand[0].length;continue}
   if(next&&'"\\/bfnrt'.includes(next)){output+=char+next;i++;continue}
   if(next==="u"&&/^[\da-f]{4}$/i.test(text.slice(i+2,i+6))){
     output+=text.slice(i,i+6);i+=5;continue;
   }
   output+="\\\\";
 }
 return output;
}

function parseQuizInput(raw){
  let text=String(raw??"").trim();
  if(!text)throw Error("Paste quiz JSON first.");

  // Accept ```json ... ```, ``` ... ```, or plain pasted JSON.
  text=text.replace(/^\uFEFF/,"").trim();
  text=text.replace(/^```(?:json|JSON|javascript|js)?\s*/,"").replace(/\s*```$/,"").trim();

  // If explanatory text was copied around the JSON, isolate the first complete
  // object/array. This is deliberately conservative and only runs if direct
  // JSON.parse fails.
  const direct=()=>{
    try{return JSON.parse(text)}catch(e){return null}
  };
  let parsed=direct();
  if(parsed!==null)return parsed;

  const escapedBackslashes=escapeInvalidJsonBackslashes(text);
  try{return JSON.parse(escapedBackslashes)}catch(e){}

  let candidate=text;
  const firstObj=text.indexOf("{"),firstArr=text.indexOf("[");
  let start=-1;
  if(firstObj<0)start=firstArr;
  else if(firstArr<0)start=firstObj;
  else start=Math.min(firstObj,firstArr);
  if(start>0)candidate=text.slice(start);
  candidate=escapeInvalidJsonBackslashes(candidate);

  // Remove JS-style comments outside strings and trailing commas.
  candidate=candidate
    .replace(/\/\*[\s\S]*?\*\//g,"")
    .replace(/(^|[^:\\])\/\/[^\r\n]*/g,"$1")
    .replace(/,\s*([}\]])/g,"$1");

  // Common copy/paste issue: smart quotes.
  candidate=candidate
    .replace(/[\u201C\u201D]/g,'"')
    .replace(/[\u2018\u2019]/g,"'");

  try{return JSON.parse(candidate)}catch(e){}

  // Allow unquoted object keys: {question:"...", options:[...]}.
  candidate=candidate.replace(/([{,]\s*)([A-Za-z_$][\w$-]*)(\s*:)/g,"$1\"$2\"$3");

  // Allow simple single-quoted JSON strings when the content contains no
  // unescaped apostrophe. This is only a fallback after real JSON failed.
  candidate=candidate.replace(/'([^'\\]*(?:\\.[^'\\]*)*)'/g,(m,s)=>{
    return '"'+s.replace(/"/g,'\\"')+'"';
  });

  try{return JSON.parse(candidate)}catch(e){
    // Final recovery: if surrounding plain text remains, isolate the last
    // closing brace/bracket and retry.
    const end=Math.max(candidate.lastIndexOf("}"),candidate.lastIndexOf("]"));
    if(end>=0){
      const clipped=candidate.slice(0,end+1);
      try{return JSON.parse(clipped)}catch(_){}
    }
    throw Error("Quiz JSON could not be parsed. Escape LaTeX backslashes inside JSON strings (for example, write `\\\\lambda` or `\\\\|`). You can paste plain JSON or wrap it in a ```json code block.");
  }
}

function parseQuiz(data){
 let qs=[],secs=[],name="Imported CBQ",duration=0,hasDuration=false;
 if(Array.isArray(data)){
   qs=data.map(q=>normalize(q));
 }else if(data&&Array.isArray(data.sections)){
   name=data.name||name;
   data.sections.forEach(s=>{
     if(!Array.isArray(s.questions))throw Error("A section is missing its questions array.");
     s.questions.forEach(q=>qs.push(normalize(q,s)));
     if(s.timeMinutes!=null){duration+=Number(s.timeMinutes||0);hasDuration=true}
     secs.push({name:s.name||"General",timeMinutes:s.timeMinutes,marks:s.marks,negativeMarks:s.negativeMarks});
   });
   if(data.timeMinutes!=null){duration=Number(data.timeMinutes);hasDuration=true}
 }else throw Error("Use a flat JSON array or an object containing sections.");
 if(Array.isArray(data)&&data.timeMinutes!=null){duration=Number(data.timeMinutes);hasDuration=true}
 if(!qs.length)throw Error("No questions found.");
 if(!hasDuration)duration=settings.defaultDuration||5;
 return {name,questions:qs,sections:secs,durationMinutes:clampDurationMinutes(duration)};
}
function openImporter(){document.getElementById("importer").classList.add("show");document.getElementById("jsonInput").value="";document.getElementById("jsonStatus").textContent="";setTimeout(()=>document.getElementById("jsonInput").focus(),40)}
function closeImporter(){document.getElementById("importer").classList.remove("show")}
function readFile(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>document.getElementById("jsonInput").value=r.result;r.readAsText(f)}
function loadQuiz(){
 try{
   const parsed=parseQuiz(parseQuizInput(document.getElementById("jsonInput").value));
   questions=prepareShuffledQuiz(parsed.questions);sections=parsed.sections;examName=parsed.name;examId=id();
   answers=Array(questions.length).fill(null);reviews=new Set();checkedQuestions=new Set();matchOrders={};current=0;
   quizDurationMinutes=clampDurationMinutes(parsed.durationMinutes,settings.defaultDuration||5);seconds=quizDurationMinutes*60;timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;sessionId=null;examFinished=false;
   if(document.getElementById("examTitle"))document.getElementById("examTitle").textContent=examName;document.getElementById("headerQuizName").textContent=examName;
   if(document.getElementById("examMeta"))document.getElementById("examMeta").textContent=`${questions.length} questions · ${quizDurationMinutes} min · scoring from JSON`;
   registerActiveExam();closeImporter();showView("exam");render();saveSession();toast(`Loaded ${questions.length} questions ✓`);
 }catch(e){document.getElementById("jsonStatus").className="status err";document.getElementById("jsonStatus").textContent="✕ "+e.message}
}


function protectQuizCodeAndMath(root){
  if(!root)return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
  nodes.forEach(node=>{
    const parent=node.parentElement;
    if(!parent||parent.closest("pre,code,.katex,.katex-display"))return;
    const text=node.nodeValue;
    if(!text||!text.trim())return;

    let out=text;
    // Fenced code: ```language\n...\n```
    out=out.replace(/```([A-Za-z0-9_+-]*)[ \t]*\n?([\s\S]*?)```/g,
      (_,lang,code)=>`<pre class="quiz-code-block"><code>${esc(code)}</code></pre>`);
    // Inline code: `...`
    out=out.replace(/`([^`\n]+)`/g,
      (_,code)=>`<code class="quiz-inline-code">${esc(code)}</code>`);

    if(out!==text){
      const holder=document.createElement("span");
      holder.innerHTML=out;
      const frag=document.createDocumentFragment();
      while(holder.firstChild)frag.appendChild(holder.firstChild);
      node.parentNode.replaceChild(frag,node);
    }
  });
}
function normalizeQuizLatex(root){
  if(!root)return;
  const isInsideMathDelimiter=(text,index)=>{
    let open=null;
    const delimiters=/\$\$?|\\\[|\\\]|\\\(|\\\)/g;
    delimiters.lastIndex=0;
    let match;
    while((match=delimiters.exec(text))&&match.index<index){
      const token=match[0];
      if(!open){
        if(token==="$"||token==="$$")open=token;
        else if(token==="\\[")open="\\]";
        else if(token==="\\(")open="\\)";
      }else if(token===open){
        open=null;
      }
    }
    return !!open;
  };
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
  nodes.forEach(node=>{
    const parent=node.parentElement;
    if(!parent||parent.closest("pre,code,.katex,.katex-display"))return;
    const text=node.nodeValue;
    if(!text||!text.includes("\\begin{"))return;

    let out=text.replace(/\\begin\{(align|equation|gather|multline)\*?\}/g,(_,env)=>`\\begin{${env==="align"||env==="equation"?"aligned":env==="gather"||env==="multline"?"gathered":env}}`)
      .replace(/\\end\{(align|equation|gather|multline)\*?\}/g,(_,env)=>`\\end{${env==="align"||env==="equation"?"aligned":env==="gather"||env==="multline"?"gathered":env}}`);
    const bareEnvironment=/\\begin\{(aligned|gathered)\}[\s\S]*?\\end\{\1\}/g;
    out=out.replace(bareEnvironment,(match,_,offset,whole)=>isInsideMathDelimiter(whole,offset)?match:`$$${match}$$`);
    if(out!==text)node.nodeValue=out;
  });
}
function formatExplanationText(text){
  if(text==null)return "";
  return String(text).trim();
}
function renderQuizInlineMarkdown(text){
  const tokens=[];
  const hold=html=>`\uE000${tokens.push(html)-1}\uE001`;
  const protectedText=String(text).replace(/(`[^`\n]+`|\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$[^$\n]+\$)/g,match=>{
    if(match[0]==="`")return hold(`<code class="quiz-inline-code">${esc(match.slice(1,-1))}</code>`);
    return hold(esc(match));
  });
  let html=esc(protectedText);
  html=html
    .replace(/&lt;u&gt;([\s\S]+?)&lt;\/u&gt;/gi,"<u>$1</u>")
    .replace(/\+\+([^+\n]+)\+\+/g,"<u>$1</u>")
    .replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>")
    .replace(/(^|[^\w])__([^_\n]+)__(?!\w)/g,"$1<strong>$2</strong>")
    .replace(/~~([^~\n]+)~~/g,"<del>$1</del>")
    .replace(/\*([^*\n]+)\*/g,"<em>$1</em>")
    .replace(/(^|[^\w])_([^_\n]+)_(?!\w)/g,"$1<em>$2</em>");
  return html.replace(/\uE000(\d+)\uE001/g,(_,index)=>tokens[Number(index)]);
}
function quizMarkdownHtml(text){
  const lines=String(text??"").replace(/\\n/g,"\n").replace(/\r\n?/g,"\n").split("\n");
  const blocks=[];
  let paragraph=[],i=0;
  const flushParagraph=()=>{
    if(paragraph.length){
      blocks.push(`<p>${paragraph.map(renderQuizInlineMarkdown).join("<br>")}</p>`);
      paragraph=[];
    }
  };
  while(i<lines.length){
    const line=lines[i],trimmed=line.trim();
    if(!trimmed){flushParagraph();i++;continue}
    if(/^```/.test(trimmed)){
      flushParagraph();
      const inlineWithLanguage=trimmed.match(/^```([A-Za-z0-9_+-]+)[ \t]+([\s\S]*?)```$/);
      const isSingleLine=trimmed.length>=6&&trimmed.endsWith("```");
      const lang=(inlineWithLanguage?.[1]||"").replace(/[^A-Za-z0-9_+-]/g,"");
      const code=inlineWithLanguage
        ?[inlineWithLanguage[2].trimEnd()]
        :isSingleLine
          ?[trimmed.slice(3,-3)]
          :[];
      if(!isSingleLine){
        i++;
        while(i<lines.length&&!/^```/.test(lines[i].trim()))code.push(lines[i++]);
        if(i<lines.length)i++;
      }else i++;
      blocks.push(`<pre class="quiz-code-block"><code${lang?` class="language-${lang}"`:""}>${esc(code.join("\n"))}</code></pre>`);
      continue;
    }
    const heading=trimmed.match(/^(#{1,3})\s+(.+)$/);
    if(heading){
      flushParagraph();
      const level=heading[1].length+2;
      blocks.push(`<h${level}>${renderQuizInlineMarkdown(heading[2])}</h${level}>`);
      i++;continue;
    }
    const listItem=trimmed.match(/^([-*+]|\d+[.)])\s+(.+)$/);
    if(listItem){
      flushParagraph();
      const ordered=/^\d/.test(listItem[1]),items=[];
      while(i<lines.length){
        const match=lines[i].trim().match(/^([-*+]|\d+[.)])\s+(.+)$/);
        if(!match||/^\d/.test(match[1])!==ordered)break;
        items.push(`<li>${renderQuizInlineMarkdown(match[2])}</li>`);
        i++;
      }
      blocks.push(`<${ordered?"ol":"ul"}>${items.join("")}</${ordered?"ol":"ul"}>`);
      continue;
    }
    paragraph.push(line);i++;
  }
  flushParagraph();
  return blocks.join("");
}
function setQuizRichText(element,text){
  if(!element)return;
  element.classList.add("quiz-rich-text");
  element.innerHTML=quizMarkdownHtml(text);
}
function setQuizExplanation(element,text){
  if(!element)return;
  element.innerHTML='<strong><svg class="ui-icon"><use href="#icon-lightbulb"/></svg> Explanation</strong>';
  const content=document.createElement("div");
  content.className="explanation-content";
  setQuizRichText(content,formatExplanationText(text));
  element.appendChild(content);
  renderAllQuizMath(element);
}
function renderAllQuizMath(root=document){
  if(!root||typeof renderMathInElement!=="function")return;
  protectQuizCodeAndMath(root);
  normalizeQuizLatex(root);
  const cfg={
    delimiters:[
      {left:"$$",right:"$$",display:true},
      {left:"\\[",right:"\\]",display:true},
      {left:"$",right:"$",display:false},
      {left:"\\(",right:"\\)",display:false}
    ],
    throwOnError:false,strict:false,trust:false,
    macros:{
      "\\R":"\\mathbb{R}",
      "\\N":"\\mathbb{N}",
      "\\Z":"\\mathbb{Z}",
      "\\Q":"\\mathbb{Q}",
      "\\C":"\\mathbb{C}"
    }
  };
  try{renderMathInElement(root,cfg)}catch(e){}
}

function renderMath(){
  renderAllQuizMath(document.getElementById("examView")||document);
}

const examflowMathObserver=new MutationObserver(mutations=>{
  for(const m of mutations){
    if(m.addedNodes&&m.addedNodes.length){
      m.addedNodes.forEach(n=>{if(n.nodeType===1)renderAllQuizMath(n)});
    }
  }
});
document.addEventListener("DOMContentLoaded",()=>{
  const root=document.getElementById("examView")||document.body;
  examflowMathObserver.observe(root,{childList:true,subtree:true});
});

const __examflowRenderWithMath=render;
render=function(){
  __examflowRenderWithMath();
  renderAllQuizMath(document.getElementById("examView")||document);
};

function renderQuestionImage(q){
 const old=document.getElementById("questionImage");
 if(old)old.remove();
 if(!q.image)return;
 const img=document.createElement("img");
 img.id="questionImage";img.src=q.image;img.alt="Question image";
 img.addEventListener("error",()=>{img.replaceWith(Object.assign(document.createElement("div"),{id:"questionImage",className:"question-image-error",textContent:"Image could not be loaded. Check that the URL or embedded data is valid."}))},{once:true});
 img.style.cssText="display:block;max-width:100%;max-height:360px;object-fit:contain;margin:10px auto 18px;border-radius:10px;border:1px solid var(--line);";
 const qt=document.getElementById("questionText");
 qt.parentNode.insertBefore(img,qt.nextSibling);
}
function renderSpecialQuestion(q,opts){
 opts.innerHTML="";
 if(q.type==="fill_blank"){
   const wrap=document.createElement("div");
   wrap.className="special-answer";
   const input=document.createElement("input");
   input.className="fill-answer";input.placeholder="Type your answer…";input.autocomplete="off";
   input.value=answers[current]||"";
   input.oninput=()=>{answers[current]=input.value;checkedQuestions.delete(current);clearVerifiedFeedback();saveSessionSoon()};
   input.onkeydown=e=>{
     if(e.key==="Enter"&&!e.shiftKey&&!e.ctrlKey&&!e.metaKey){
       e.preventDefault();e.stopPropagation();checkCurrentAnswer();
     }
   };
   wrap.appendChild(input);opts.appendChild(wrap);
 }else if(q.type==="match"||q.type==="drag_drop"){
   const chosen=answers[current]||[];
   const rights=q.pairs.map(p=>p.right);
   if(!matchOrders[current]){
     const indexed=rights.map((right,i)=>({right,i}));
     // Fisher-Yates once per question; the resulting order is retained.
     for(let i=indexed.length-1;i>0;i--){
       const j=Math.floor(Math.random()*(i+1));
       [indexed[i],indexed[j]]=[indexed[j],indexed[i]];
     }
     matchOrders[current]=indexed.map(x=>x.right);
     saveSessionSoon();
   }
   const shuffled=matchOrders[current];
   const grid=document.createElement("div");grid.className="matching-grid";
   q.pairs.forEach((pair,i)=>{
     const row=document.createElement("div");row.className="match-row";
     const left=document.createElement("div");left.className="match-left";
     left.innerHTML=esc(pair.left);

     const wrap=document.createElement("div");wrap.className="match-choice";
     const selected=chosen[i]||"";
     const trigger=document.createElement("button");
     trigger.type="button";trigger.className="match-trigger";
     trigger.innerHTML=selected?`<span class="match-selected">${esc(selected)}</span><span class="match-chevron">⌄</span>`:`<span class="match-placeholder">Choose match…</span><span class="match-chevron">⌄</span>`;

     const menu=document.createElement("div");menu.className="match-menu";
     menu.innerHTML=shuffled.map((x,k)=>`<button type="button" class="match-menu-item${String(x)===String(selected)?" selected":""}" data-value="${esc(x)}"><span>${String.fromCharCode(65+k)}</span><span class="match-menu-text">${esc(x)}</span></button>`).join("");
     menu.querySelectorAll(".match-menu-item").forEach(item=>{
       item.onclick=()=>{
         const value=item.getAttribute("data-value")||"";
         const a=Array.isArray(answers[current])?[...answers[current]]:Array(q.pairs.length).fill("");
         a[i]=value;answers[current]=a;checkedQuestions.delete(current);saveSessionSoon();render();
       };
     });
     trigger.onclick=e=>{
       e.stopPropagation();
       document.querySelectorAll(".match-choice.open").forEach(x=>{if(x!==wrap)x.classList.remove("open")});
       wrap.classList.toggle("open");
     };
     wrap.append(trigger,menu);

     if(mode==="practice"&&checkedQuestions.has(current)){
       const ok=String(chosen[i]??"").trim().toLowerCase()===String(pair.right??"").trim().toLowerCase();
       row.classList.add(ok?"match-correct":"match-wrong");
       const label=document.createElement("div");label.className="match-result-label";label.textContent=ok?"✓ Correct":"✕ Incorrect";
       row.append(left,wrap,label);
     }else row.append(left,wrap);
     grid.appendChild(row);
   });
   opts.appendChild(grid);
   renderAllQuizMath(grid);
   if(q.type==="drag_drop"){
     const hint=document.createElement("div");hint.className="drag-hint";hint.textContent="↕ Match each item using the selectors.";opts.appendChild(hint);
   }
   if(mode==="practice"){
     const check=document.createElement("button");
     check.type="button";check.className="btn primary match-check-btn";
     check.textContent="✓ Check matches";
     check.onclick=()=>{if(!answerIsPresent(answers[current],q)){toast("Complete every match first");return}checkedQuestions.add(current);render();saveSessionSoon()};
     opts.appendChild(check);
   }
 }else if(q.type==="ordering"){
   const currentOrder=Array.isArray(answers[current])&&answers[current].length?answers[current]:[...q.options];
   const list=document.createElement("div");list.className="ordering-list";
   list.setAttribute("role","list");
   list.setAttribute("aria-label","Reorder the steps");
   const moveItem=(from,to)=>{
     if(from===to||to<0||to>=currentOrder.length)return;
     const nextOrder=[...currentOrder];
     const [moved]=nextOrder.splice(from,1);
     nextOrder.splice(to,0,moved);
     answers[current]=nextOrder;
     checkedQuestions.delete(current);
     render();
     const updatedItems=document.querySelectorAll("#options .order-item");
     updatedItems.forEach(el=>el.classList.add("order-item-updated"));
     saveSessionSoon();
   };
   currentOrder.forEach((item,i)=>{
     const card=document.createElement("div");
     card.className="order-item";
     card.draggable=true;
     card.setAttribute("role","listitem");
     card.dataset.orderIndex=String(i);
     const position=document.createElement("span");position.className="order-position";position.textContent=String(i+1);
     const content=document.createElement("div");content.className="order-content";setQuizRichText(content,String(item));
     const handle=document.createElement("span");handle.className="order-handle";handle.setAttribute("aria-hidden","true");handle.textContent="⠿";
     const controls=document.createElement("div");controls.className="order-controls";
     const up=document.createElement("button");up.type="button";up.className="order-move";up.textContent="↑";up.setAttribute("aria-label",`Move item ${i+1} up`);up.disabled=i===0;up.onclick=()=>moveItem(i,i-1);
     const down=document.createElement("button");down.type="button";down.className="order-move";down.textContent="↓";down.setAttribute("aria-label",`Move item ${i+1} down`);down.disabled=i===currentOrder.length-1;down.onclick=()=>moveItem(i,i+1);
     controls.append(up,down);
     card.append(handle,position,content,controls);
     card.ondragstart=e=>{
       e.dataTransfer.setData("text/plain",String(i));
       e.dataTransfer.effectAllowed="move";
       card.classList.add("is-dragging");
     };
     card.ondragend=()=>card.classList.remove("is-dragging");
     card.ondragover=e=>{e.preventDefault();e.dataTransfer.dropEffect="move";card.classList.add("is-drop-target")};
     card.ondragleave=e=>{if(!card.contains(e.relatedTarget))card.classList.remove("is-drop-target")};
     card.ondrop=e=>{
       e.preventDefault();
       const from=Number(e.dataTransfer.getData("text/plain"));
       card.classList.remove("is-drop-target");
       moveItem(from,i);
     };
     list.appendChild(card);
   });
   opts.appendChild(list);
 }else{
   q.options.forEach((text,i)=>{
     const letter=String.fromCharCode(65+i),b=document.createElement("button");
     b.className="option"+(answers[current]===letter?" selected":"");
     const letterEl=document.createElement("span");letterEl.className="letter";letterEl.textContent=letter;
     const textEl=document.createElement("div");textEl.className="option-text";setQuizRichText(textEl,text);
     b.append(letterEl,textEl);
     b.onclick=()=>choose(letter);opts.appendChild(b);
   });
 }
}
function isQuestionCorrect(q,ans){
 if(q.type==="fill_blank"){
   return q.acceptedAnswers.some(x=>String(x).trim().toLowerCase()===String(ans??"").trim().toLowerCase());
 }
 if(q.type==="match"||q.type==="drag_drop"){
   if(!Array.isArray(ans)||ans.length!==q.pairs.length)return false;
   return q.pairs.every((pair,i)=>{
     const selected=String(ans[i]??"").trim().toLowerCase();
     const expected=String(pair.right??"").trim().toLowerCase();
     return selected!=="" && selected===expected;
   });
 }
 if(q.type==="ordering"){
   return Array.isArray(ans)&&ans.length===q.answer.length&&q.answer.every((x,i)=>String(ans[i])===String(x));
 }
 return ans===q.answer;
}
function answerIsPresent(ans,q){
 if(ans==null)return false;
 if(q.type==="fill_blank")return String(ans).trim()!=="";
 if(q.type==="match"||q.type==="drag_drop")return Array.isArray(ans)&&ans.length===q.pairs.length&&ans.every(x=>String(x??"").trim()!=="");
 if(q.type==="ordering")return Array.isArray(ans)&&ans.length===q.answer.length&&ans.every(x=>String(x).trim()!=="");
 return !!ans;
}

/* Fast keyboard workflow */
let examflowKeyboardShortcuts={busy:false};
function isTypingTarget(el){
  if(!el)return false;
  const tag=(el.tagName||"").toLowerCase();
  return tag==="input"||tag==="textarea"||tag==="select"||el.isContentEditable;
}
async function examflowCtrlEnter(){
  const importer=document.getElementById("importer");
  const homeInput=document.getElementById("homeJson");
  if(!importer?.classList.contains("show") && document.getElementById("homeView")?.classList.contains("active") && homeInput?.value.trim()){
    startHomeQuiz();
    return;
  }
  const input=document.getElementById("jsonInput");
  if(importer?.classList.contains("show") && input){
    // Ctrl+Enter starts the JSON already pasted into the importer.
    if(examflowKeyboardShortcuts.busy)return;
    examflowKeyboardShortcuts.busy=true;
    try{
      const before=input.value.trim();
      if(!before){
        try{await pasteFromClipboard("jsonInput","jsonStatus","importPasteBtn")}catch(e){}
      }
      if(input.value.trim())loadQuiz();else toast("Paste quiz JSON first");
    }finally{examflowKeyboardShortcuts.busy=false}
    return;
  }
  if(document.getElementById("homeView")?.classList.contains("active")){
    openImporter();
    setTimeout(()=>examflowCtrlEnter(),60);
  }
}
function examflowSelectOptionByNumber(n){
  if(!questions.length||!document.getElementById("examView")?.classList.contains("active"))return;
  const q=questions[current];
  if(!Array.isArray(q.options)||n<1||n>q.options.length)return;
  if(q.type==="fill_blank"||q.type==="match"||q.type==="drag_drop"||q.type==="ordering")return;
  choose(String.fromCharCode(64+n));
}
function examflowKeyboardHandler(e){
  const key=e.key, lower=key.toLowerCase(), typing=isTypingTarget(e.target);

  if(e.key==="Escape"){
    closeImporter();closeSubmit();closeSessions();
    if(typeof closeCBQModal === "function") closeCBQModal();
    const drawer=document.getElementById("examProgressDrawer");
    if(drawer?.classList.contains("open"))toggleQuestionProgress();
    if(document.activeElement) document.activeElement.blur();
    return;
  }

  // Confirm submission from the open dialog without affecting answer checking.
  if(e.key==="Enter" && !e.shiftKey && !e.ctrlKey && !e.metaKey && document.getElementById("submitModal")?.classList.contains("show")){
    e.preventDefault();
    finishTest();
    return;
  }

  if((e.ctrlKey||e.metaKey)&&e.key==="Enter"&&document.getElementById("plannerView")?.classList.contains("active")){
    e.preventDefault();
    saveQuickPlan();
    return;
  }

  // Ctrl/Cmd+Enter is the single intentional exception to the browser guard.
  if((e.ctrlKey||e.metaKey)&&e.key==="Enter" && (document.getElementById("importer")?.classList.contains("show") || document.getElementById("homeView")?.classList.contains("active"))){
    e.preventDefault();
    examflowCtrlEnter();
    return;
  }

  // Never capture browser-reserved Ctrl/Cmd shortcuts such as Save or Open.
  if(e.ctrlKey||e.metaKey)return;

  // Never hijack normal text editing.
  if(typing)return;

  // Alt+number navigation stays separate from quiz answer keys and browser tabs.
  if(e.altKey && !e.shiftKey && /^[1-4]$/.test(e.key)){
    e.preventDefault();
    const page=["home","exam","planner","settings"][Number(e.key)-1];
    if(page)showView(page);
    return;
  }
  if(e.altKey && lower==="m"){e.preventDefault();toggleMobileNav();return}
  if(e.altKey && lower==="i"){e.preventDefault();openImporter();return}
  if(e.altKey && lower==="x"){e.preventDefault();exportData();return}
  if(e.altKey && lower==="s"){
    if(document.getElementById("examView")?.classList.contains("active")){e.preventDefault();saveSession();toast("Session saved ✓")}
    return;
  }

  if(e.shiftKey && !e.altKey && lower==="l"){e.preventDefault();setTheme("light");return}
  if(e.shiftKey && !e.altKey && lower==="d"){e.preventDefault();setTheme("dark");return}

  const resultsActive=document.getElementById("testResultsView")?.classList.contains("active");
  if(resultsActive){
    if(e.key==="ArrowRight"||e.key==="ArrowLeft"){
      e.preventDefault();
      moveResultQuestion(e.key==="ArrowRight"?1:-1);
      return;
    }
    if(e.shiftKey&&lower==="r"){e.preventDefault();retakeLastTest();return}
    if(e.shiftKey&&lower==="s"){e.preventDefault();saveResultCopy();return}
    if(e.shiftKey&&lower==="c"){e.preventDefault();showView("home");return}
    return;
  }

  const examActive=document.getElementById("examView")?.classList.contains("active");
  if(!examActive)return;

  if(!e.shiftKey&&!e.altKey){
    if(lower==="h"){e.preventDefault();toggleHint();return}
    if(lower==="p"){e.preventDefault();toggleQuestionProgress();return}
    if(lower==="c"){e.preventDefault();copyCurrentQuestion();return}
    if(lower==="g"){e.preventDefault();redirectQuestionToChatGPT();return}
    if(lower==="r"){e.preventDefault();toggleReview();return}
    if(lower==="v"&&mode==="practice"){e.preventDefault();viewPracticeAnswer();return}
  }

  if(e.shiftKey){
    if(lower==="p"){e.preventDefault();setMode("practice");return}
    if(lower==="e"){e.preventDefault();setMode("exam");return}
    if(lower==="s"){e.preventDefault();submitExam();return}
    return;
  }

  if(e.key==="ArrowRight"){
    e.preventDefault();
    nextQuestion();
    return;
  }
  if(e.key==="ArrowLeft"){
    e.preventDefault();
    previousQuestion();
    return;
  }
  if(e.key==="Enter"){e.preventDefault();checkCurrentAnswer();return}
  if(e.key==="Delete" || e.key==="Backspace"){e.preventDefault();clearAnswer();return}
  if(/^[1-4]$/.test(e.key)){e.preventDefault();examflowSelectOptionByNumber(Number(e.key));return}
}

/* Single keyboard router: all app shortcuts live here. */
document.addEventListener("keydown",examflowKeyboardHandler,true);


/* Lightweight click pulse: visual confirmation for every interactive button */
document.addEventListener("pointerdown",e=>{
  const b=e.target.closest("button,.btn,.modebtn,.preset-btn,.bookmark,.qbtn");
  if(!b||b.disabled)return;
  if(b.id!=="soundOffBtn")playButtonSound();
  b.classList.remove("click-pulse");
  void b.offsetWidth;
  b.classList.add("click-pulse");
  setTimeout(()=>b.classList.remove("click-pulse"),180);
});

const CBQ_MODE_GUIDE=`LANGUAGE STYLE:
Use ASD-STE100-inspired controlled English for about 80% of the wording.
- Use short sentences.
- Use simple grammar and one idea at a time.
- Use clear technical terms.
- Avoid unnecessary synonyms and decorative academic wording.
- Keep mathematical and computer science terms precise.
- Simplify the language, not the thinking. Keep the reasoning deep.

TEXT FORMATTING:
Use Markdown where it improves readability: **bold**, *italic*, ++underline++, inline or fenced code, and bullet or numbered lists. Do not use raw HTML.

CBQ COMMAND MODES:
Read any CBQ command included with the topic, source, or question. A command starts with CBQ/. Commands can be combined. Apply every requested mode together.
- CBQ/mental: mental-set and problem-solving aptitude.
- CBQ/depth: deep conceptual understanding.
- CBQ/math: mathematical derivation and reasoning.
- CBQ/bloom: progress through Bloom's taxonomy.
- CBQ/normal: use mixed question formats.
- CBQ/code: reason about code or pseudocode.
- CBQ/RQ: reconstruct code line by line.
- CBQ/hint: link hints across a chain of reasoning.
- CBQ/active: use active recall and many fill-in-the-blank questions.
- CBQ/match: match related items, relationships, or formulas.
- CBQ/5x25: teach 5 core ideas, then create 25 reinforcement questions.
- CBQ/leetcode: transfer the concept to a LeetCode-style problem.
- CBQ/source: ground coverage in the supplied source, slides, or notes.
- CBQ/diagnose: detect misconceptions and repair them.
- CBQ/transfer: apply the concept to novel situations.
- CBQ/reconstruct: rebuild an algorithm or process from reasoning.

PRIMARY MODES:
CBQ/mental, CBQ/depth, CBQ/math, CBQ/code, CBQ/RQ, CBQ/hint, CBQ/leetcode, CBQ/source, CBQ/diagnose, and CBQ/transfer are the main specialized modes.

COMBINED MODES:
- CBQ/mental/depth: build a mental model and deepen understanding step by step.
- CBQ/mental/code: build problem-solving skill through code.
- CBQ/mental/leetcode: teach problem-solving patterns, then transfer them to a LeetCode-style problem.
- CBQ/depth/math: derive the mathematical idea instead of memorizing a formula.
- CBQ/source/mental: use the supplied source while training problem-solving aptitude.
- CBQ/code/RQ: understand an implementation, then reconstruct it line by line.
- CBQ/mental/diagnose/transfer: identify the reasoning pattern, find mistakes, then apply the idea to a new problem.
For other combinations, combine their intentions without dropping a requested mode.

DEFAULT MODE:
If the user says only "CBQ" and gives no specialized command, use CBQ/mental/depth: deep understanding plus problem-solving aptitude. A supplied CBQ/ command replaces this default or adds specialized modes.
Unless CBQ/5x25 is requested, create exactly 5 connected, progressively deeper questions. CBQ/5x25 instead requires 5 core ideas followed by 25 reinforcement questions.`;

let promptLibrary={version:1,activeId:null,prompts:[]};
const promptDrafts=new Map();
const fixedQuestionPrompt="Create 5 connected Concept Breakdown Quiz questions that build reasoning toward this problem, ending with transfer. Use plain English. Honor CBQ/ modes in the source (default mental/depth; 5x25 means 5 core ideas + 25 questions). Include answers and concise explanations; optional hints. Return only a JSON code block using this ExamFlow structure (MCQs: 2 options, answer A or B). Escape LaTeX backslashes in JSON.\n{\"name\":\"CBQ\",\"sections\":[{\"name\":\"Reasoning\",\"timeMinutes\":10,\"marks\":1,\"negativeMarks\":0,\"questions\":[{\"type\":\"mcq\",\"question\":\"…\",\"options\":[\"…\",\"…\"],\"answer\":\"A\",\"explanation\":\"…\"}]}]}\nSource: {{question}}";
function validPromptLibrary(data){
 if(!data||data.version!==1||!Array.isArray(data.prompts)||!data.prompts.length)throw Error("No prompt slots found.");
 const ids=new Set();
 for(const p of data.prompts){
  if(!p||typeof p.id!=="string"||ids.has(p.id)||typeof p.name!=="string"||!p.name.trim()||typeof p.text!=="string")throw Error("Each slot needs a unique ID, name and prompt.");
  ids.add(p.id);
 }
 return {version:1,prompts:data.prompts.map(p=>({id:p.id,name:p.name,text:p.text})),activeId:ids.has(data.activeId)?data.activeId:data.prompts[0].id};
}
function activePrompt(){return promptLibrary.prompts.find(p=>p.id===promptLibrary.activeId)}
function getPromptText(){return activePrompt()?.text||""}
function promptStatus(message,error=false){
 const status=document.getElementById("seedPromptStatus");
 status.textContent=message;status.style.color=error?"var(--bad)":"var(--muted)";
}
function renderPromptSlots(){
 const list=document.getElementById("promptSlotList");if(!list)return;
 list.replaceChildren();
 for(const p of promptLibrary.prompts){
  const draft=promptDrafts.get(p.id),name=draft?.name||p.name,text=draft?.text??p.text;
  const button=document.createElement("button");button.type="button";button.className="prompt-slot"+(p.id===promptLibrary.activeId?" is-active":"");button.setAttribute("aria-pressed",String(p.id===promptLibrary.activeId));
  const title=document.createElement("strong");title.textContent=name;
  const meta=document.createElement("span");meta.textContent=`${text.length.toLocaleString()} chars${draft?" · Draft":""}${p.id===promptLibrary.activeId&&p.text.trim()?" · Used for copying":""}`;
  button.append(title,meta);button.onclick=()=>selectPromptSlot(p.id);list.append(button);
 }
 if(!list.children.length){const empty=document.createElement("p");empty.className="prompt-empty";empty.textContent="No prompts yet.";list.append(empty)}
 document.getElementById("promptSlotCount").textContent=`${promptLibrary.prompts.length} slots`;
}
function renderPromptSettings(){
 const editor=document.getElementById("seedPromptEditor");if(!editor)return;
 const p=activePrompt(),draft=p&&promptDrafts.get(p.id);
 document.getElementById("promptSlotName").value=draft?.name??p?.name??"";
 editor.value=draft?.text??p?.text??"";
 document.querySelectorAll(".prompt-library-edit").forEach(el=>el.disabled=!p);
 const remove=document.getElementById("deletePromptBtn");if(remove)remove.disabled=promptLibrary.prompts.length<2;
 renderPromptSlots();
 promptStatus(p?`${editor.value.length.toLocaleString()} characters · ${draft?"Draft preserved":"Saved slot"}`:"No prompts loaded. Serve the project over HTTP to load the prompt library.");
}
function editPrompt(){
 const p=activePrompt();if(!p)return;
 promptDrafts.set(p.id,{name:document.getElementById("promptSlotName").value,text:document.getElementById("seedPromptEditor").value});
 backupPromptLibrary();renderPromptSlots();promptStatus(`${document.getElementById("seedPromptEditor").value.length.toLocaleString()} characters · Draft preserved`);
}
function selectPromptSlot(value){if(!promptLibrary.prompts.some(p=>p.id===value))return;promptLibrary.activeId=value;backupPromptLibrary();renderPromptSettings()}
function backupPromptLibrary(){put("examflow_prompt_library_v1",{...promptLibrary,drafts:Object.fromEntries(promptDrafts)})}
function savePrompt(){
 const p=activePrompt();if(!p)return false;
 const name=document.getElementById("promptSlotName").value.trim(),text=document.getElementById("seedPromptEditor").value;
 if(!name||!text.trim()){promptStatus("Enter a slot name and prompt.",true);return false}
 p.name=name;p.text=text;promptDrafts.delete(p.id);backupPromptLibrary();renderPromptSettings();promptStatus("Prompt saved.");return true;
}
function addPromptSlot(duplicate=false){
 const current=activePrompt(),draft=current&&promptDrafts.get(current.id);
 if(!current){promptStatus("Load the prompt library first.",true);return}
 const p={id:id(),name:duplicate?`${draft?.name||current?.name||"Prompt"} copy`:`New prompt ${promptLibrary.prompts.length+1}`,text:duplicate?(draft?.text??current.text):""};
 promptLibrary.prompts.push(p);promptLibrary.activeId=p.id;
 if(!duplicate)promptDrafts.set(p.id,{name:p.name,text:""});
 backupPromptLibrary();renderPromptSettings();document.getElementById("promptSlotName").focus();
}
function discardPromptDraft(){
 const p=activePrompt();if(!p)return;promptDrafts.delete(p.id);backupPromptLibrary();renderPromptSettings();
}
function deletePromptSlot(){
 const p=activePrompt();if(!p||promptLibrary.prompts.length<2)return;
 if(!confirm(`Delete “${p.name}” and its draft?`))return;
 promptLibrary.prompts=promptLibrary.prompts.filter(item=>item.id!==p.id);promptDrafts.delete(p.id);promptLibrary.activeId=promptLibrary.prompts[0].id;backupPromptLibrary();renderPromptSettings();
}
function copyPromptDraft(){
 const text=document.getElementById("seedPromptEditor").value;if(!text.trim()){promptStatus("Write a prompt before copying.",true);return}
 copyBeginnerSchema(text);
}
async function initPromptLibrary(){
 try{
  const response=await fetch("seed-prompts.json");if(!response.ok)throw Error("Prompt file unavailable");
  const defaults=validPromptLibrary(await response.json());
  promptLibrary=defaults;
 }catch(error){}
 try{
  const backup=get("examflow_prompt_library_v1",null);
  if(backup){
   const saved=validPromptLibrary(backup);
   // Add newly shipped slots without overwriting existing custom prompts.
   for(const p of promptLibrary.prompts)if(!saved.prompts.some(item=>item.id===p.id)){saved.prompts.push(p);}
   promptLibrary={version:1,activeId:saved.activeId,prompts:saved.prompts};

   for(const [slotId,draft] of Object.entries(backup.drafts||{}))if(saved.prompts.some(p=>p.id===slotId)&&typeof draft?.text==="string"&&typeof draft?.name==="string")promptDrafts.set(slotId,draft);
  }
 }catch(error){}
 // Repair blank slots made by the previous version, which copied saved text behind an empty draft.
 for(const p of promptLibrary.prompts){
  if(/^New prompt \d+$/.test(p.name)&&promptDrafts.get(p.id)?.text==="")p.text="";
 }
 if(settings.seedPrompt&&promptLibrary.prompts.length&&!promptLibrary.prompts.some(p=>p.id==="legacy")){
  promptLibrary.prompts.push({id:"legacy",name:"Previous custom prompt",text:settings.seedPrompt});promptLibrary.activeId="legacy";backupPromptLibrary();
 }
 renderPromptSettings();
}

function copyBeginnerSchema(override){
  const text=typeof override==="string"?override:getPromptText();
  if(!text){toast("Choose a saved prompt with text in Settings first");return}
  const done=()=>toast("AI CBQ prompt and schema copied ✓");
  if(navigator.clipboard?.writeText){
    navigator.clipboard.writeText(text).then(done).catch(()=>{
      const ta=document.createElement("textarea");
      ta.value=text;document.body.appendChild(ta);ta.select();
      try{document.execCommand("copy");done()}catch(e){toast("Copy failed")}
      ta.remove();
    });
  }else{
    const ta=document.createElement("textarea");
    ta.value=text;document.body.appendChild(ta);ta.select();
    try{document.execCommand("copy");done()}catch(e){toast("Copy failed")}
    ta.remove();
  }
}

function currentQuestionCopyText(q){
  const lines=[`Question: ${q.text||""}`];
  if(q.type)lines.push(`Type: ${q.type}`);
  if(q.type!=="ordering"&&Array.isArray(q.options)&&q.options.length)
    lines.push(`Options:\n${q.options.map((option,i)=>`${String.fromCharCode(65+i)}. ${option}`).join("\n")}`);
  if(Array.isArray(q.pairs)&&q.pairs.length)
    lines.push(`Pairs:\n${q.pairs.map(pair=>`${pair.left} → ${pair.right}`).join("\n")}`);
  if(q.type==="ordering"&&Array.isArray(q.options)&&q.options.length)
    lines.push(`Items:\n${q.options.map((item,i)=>`${i+1}. ${item}`).join("\n")}`);
  if(q.answer!==undefined)
    lines.push(`Answer: ${Array.isArray(q.answer)?q.answer.join(" → "):q.answer}`);
  if(Array.isArray(q.acceptedAnswers)&&q.acceptedAnswers.length)
    lines.push(`Accepted answers:\n${q.acceptedAnswers.join("\n")}`);
  if(q.explanation)lines.push(`Explanation:\n${q.explanation}`);
  if(q.hint)lines.push(`Hint:\n${q.hint}`);
  if(q.image)lines.push(`Image: ${q.image}`);
  return lines.join("\n\n");
}

function copyCurrentQuestion(){
  const q=questions[current];
  if(!q){toast("No question loaded");return}
  const text=currentQuestionCopyText(q);
  const done=()=>toast("Question copied ✓");
  const fallback=()=>{
    const ta=document.createElement("textarea");
    ta.value=text;ta.setAttribute("readonly","");ta.style.position="fixed";ta.style.opacity="0";
    document.body.appendChild(ta);ta.select();
    try{document.execCommand("copy");done()}catch(e){toast("Copy failed")}
    ta.remove();
  };
  if(navigator.clipboard?.writeText)navigator.clipboard.writeText(text).then(done).catch(fallback);
  else fallback();
}

function getQuestionSectionGroups(){
  const groups=new Map();
  questions.forEach((question,index)=>{
    const name=String(question.section||"General").trim()||"General";
    if(!groups.has(name))groups.set(name,[]);
    groups.get(name).push(index);
  });
  const sectionOrder=(Array.isArray(sections)?sections:[])
    .map(section=>String(section.name||"General").trim()||"General")
    .filter((name,index,names)=>names.indexOf(name)===index);
  return [...groups.entries()]
    .map(([name,indices],index)=>({name,indices,index}))
    .sort((a,b)=>{
      const aOrder=sectionOrder.indexOf(a.name),bOrder=sectionOrder.indexOf(b.name);
      if(aOrder<0&&bOrder<0)return a.index-b.index;
      if(aOrder<0)return 1;
      if(bOrder<0)return -1;
      return aOrder-bOrder;
    });
}

function renderQuestionNavigation(container,buttonClass,onSelect){
  if(!container)return;
  container.innerHTML="";
  getQuestionSectionGroups().forEach(group=>{
    const section=document.createElement("section");
    section.className="question-palette-section";
    const heading=document.createElement("div");
    heading.className="question-palette-section-heading";
    const title=document.createElement("strong");
    title.textContent=group.name;
    const count=document.createElement("small");
    count.textContent=`${group.indices.length} question${group.indices.length===1?"":"s"}`;
    heading.append(title,count);
    const grid=document.createElement("div");
    grid.className="question-palette-section-grid";
    group.indices.forEach(index=>{
      const button=document.createElement("button");
      const isAnswered=answerIsPresent(answers[index],questions[index]);
      const isCurrent=index===current;
      const isReview=reviews.has(index);
      button.className=buttonClass+
        (isCurrent?" current":"")+
        (isAnswered?" answered":"")+
        (isReview?" review":"");
      button.textContent=String(index+1);
      const state=[isCurrent?"current":"",isAnswered?"answered":"unanswered",isReview?"marked for review":""].filter(Boolean).join(", ");
      button.setAttribute("aria-label",`Question ${index+1}, ${group.name}, ${state}`);
      button.title=`Question ${index+1} · ${group.name}`;
      button.addEventListener("click",()=>onSelect(index));
      grid.appendChild(button);
    });
    section.append(heading,grid);
    container.appendChild(section);
  });
}

function render(){
 updateModeUI();
 if(!questions.length){
   document.getElementById("currentLabel").textContent="0";document.getElementById("totalLabel").textContent="0";
   document.getElementById("questionText").textContent="Paste a quiz JSON to start.";
   const emptyHint=document.getElementById("hintCard");if(emptyHint)emptyHint.hidden=true;
   document.getElementById("options").innerHTML="";document.getElementById("qgrid").innerHTML="";
   document.getElementById("progressText").textContent="0 / 0";document.getElementById("progressBar").style.width="0%";
   const copyQuestionBtn=document.getElementById("copyQuestionBtn");
   if(copyQuestionBtn)copyQuestionBtn.disabled=true;
   return;
 }
 const q=questions[current],count=answers.filter(Boolean).length;
 const apExisting=document.getElementById("practiceAnswerPanel");
 if(apExisting && apExisting.dataset.question!==String(current))apExisting.remove();
 document.getElementById("currentLabel").textContent=current+1;document.getElementById("totalLabel").textContent=questions.length;
 setQuizRichText(document.getElementById("questionText"),q.text||"");
 const hintCard=document.getElementById("hintCard"),hintText=document.getElementById("hintText"),hintToggle=document.getElementById("hintToggle");
 const hasHint=String(q.hint||"").trim()!=="";
 if(hintCard&&hintText&&hintToggle){
   hintCard.hidden=!hasHint;
   hintText.hidden=true;
   hintToggle.setAttribute("aria-expanded","false");
   hintToggle.innerHTML='<svg class="ui-icon"><use href="#icon-lightbulb"/></svg>Show hint';
   if(hasHint){setQuizRichText(hintText,q.hint);renderAllQuizMath(hintText)}
 }
 renderQuestionImage(q);
 const opts=document.getElementById("options");opts.innerHTML="";opts.classList.remove("answer-revealed");
 renderSpecialQuestion(q,opts);
 if(q.type==="fill_blank")opts.querySelector(".fill-answer")?.focus({preventScroll:true});
 renderMath();
 renderAllQuizMath(document.getElementById("examView"));
 renderAllQuizMath(opts);
 const fb=document.getElementById("feedback");
 const ex=document.getElementById("explanation");
 const ap=document.getElementById("practiceAnswerPanel");
 fb.removeAttribute("data-result");
 if(mode==="practice"&&checkedQuestions.has(current)){
   const hasAnswer=answerIsPresent(answers[current],q),correct=hasAnswer&&isQuestionCorrect(q,answers[current]);
   fb.textContent=hasAnswer?(correct?"✓ Correct":"✕ Incorrect — check the answer below"):"";
   fb.style.color="";
   if(hasAnswer)fb.dataset.result=correct?"correct":"wrong";
   applyVerifiedAnswerStyles(q,answers[current]);
   showPracticeAnswerPanel(q);
   if(q.explanation){ex.style.display="block";setQuizExplanation(ex,q.explanation)}else ex.style.display="none";
 }else{fb.textContent="";ex.style.display="none";if(ap)ap.style.display="none";}
 const bookmark=document.getElementById("bookmark");
 bookmark.innerHTML=`<svg class="ui-icon"><use href="#icon-bookmark"/></svg>${reviews.has(current)?"Marked":"Review"}`;
 bookmark.classList.toggle("saved",reviews.has(current));
 document.getElementById("prevBtn").disabled=current===0;document.getElementById("nextBtn").textContent=current===questions.length-1?"Finish":"Next →";
 document.getElementById("answeredCount").textContent=count;document.getElementById("reviewCount").textContent=reviews.size;
 document.getElementById("progressText").textContent=`${count} / ${questions.length}`;document.getElementById("progressBar").style.width=(count/questions.length*100)+"%";
 const grid=document.getElementById("qgrid");
 renderQuestionNavigation(grid,"qbtn",index=>{current=index;render();saveSessionSoon()});
 document.getElementById("options").querySelectorAll("button,input,select").forEach(el=>el.disabled=examFinished);
 ["prevBtn","viewAnswerBtn","nextBtn","bookmark"].forEach(id=>{const el=document.getElementById(id);if(el)el.disabled=examFinished});
 const copyQuestionBtn=document.getElementById("copyQuestionBtn");
 if(copyQuestionBtn)copyQuestionBtn.disabled=false;
 document.getElementById("questionText").classList.toggle("exam-finished",examFinished);
 if(document.getElementById("examProgressDrawer")?.classList.contains("open"))renderQuestionProgress();
}
function toggleHint(){
 const hintText=document.getElementById("hintText"),hintToggle=document.getElementById("hintToggle");
 if(!hintText||!hintToggle)return;
 const open=hintText.hidden;
 hintText.hidden=!open;hintToggle.setAttribute("aria-expanded",String(open));
 hintToggle.innerHTML=`<svg class="ui-icon"><use href="#icon-lightbulb"/></svg>${open?"Hide hint":"Show hint"}`;
 if(open)renderAllQuizMath(hintText);
}
function choose(letter){if(examFinished)return;answers[current]=letter;checkedQuestions.delete(current);render();saveSessionSoon()}
function clearAnswer(){if(examFinished)return;answers[current]=null;checkedQuestions.delete(current);render();saveSessionSoon()}
function toggleReview(){if(examFinished)return;reviews.has(current)?reviews.delete(current):reviews.add(current);render();saveSessionSoon()}
function nextQuestion(){if(current<questions.length-1){current++;render();if(!examFinished)saveSessionSoon()}else if(!examFinished)submitExam()}
function previousQuestion(){if(current>0){current--;render();if(!examFinished)saveSessionSoon()}}
function submitExam(){
 if(examFinished)return;
 if(!questions.length){toast("Load a quiz first");return}
 const unanswered=answers.filter(x=>!x).length;
 document.getElementById("submitText").textContent=unanswered?`You have ${unanswered} unanswered question${unanswered>1?"s":""}. Submit anyway?`:"All questions are answered. Submit and save your result?";
 document.getElementById("submitModal").classList.add("show")
}
function closeSubmit(){document.getElementById("submitModal").classList.remove("show")}
function finishTest(automatic=false){
 if(examFinished)return;
 examFinished=true;timerState.running=false;closeSubmit();render();
 const r=saveResult();saveSession();openDetailedResults(r);toast(automatic?"Time is up. Exam submitted.":`Result saved · ${r.percent}% ✓`)
}

function saveSession(){
 if(!questions.length)return;
 const sessions=get(K.sessions,[]),now=new Date().toISOString(),sid=sessionId||id();sessionId=sid;
 const item={id:sid,examId:examId||sid,name:examName,questions,answers,reviews:[...reviews],checkedQuestions:[...checkedQuestions],matchOrders,current,seconds,quizDurationMinutes,mode,sections,examFinished,examTimerSeconds:timerState.examSeconds,practiceTimerSeconds:timerState.practiceSeconds,practiceTimerRunning:timerState.running,updatedAt:now};
 const old=sessions.find(x=>x.id===sid);if(old)Object.assign(old,item);else sessions.unshift(item);
 put(K.sessions,sessions);recordStudyActivity(item);renderSessions()
}
let saveTimer;function saveSessionSoon(){clearTimeout(saveTimer);saveTimer=setTimeout(saveSession,120)}
function renderSessions(){
 const el=document.getElementById("sessionList"),ss=get(K.sessions,[]);
 el.innerHTML=ss.length?ss.slice(0,20).map(s=>`<div class="session-item"><button class="session-load" onclick="restoreSession('${s.id}')" title="${esc(s.name)}">${esc(s.name)} · ${s.answers.filter(Boolean).length}/${s.questions.length}</button><button class="session-delete" onclick="deleteSession('${s.id}')">×</button></div>`).join(""):'<div class="empty">No saved sessions.</div>';
}
function restoreSession(sid){
 const s=get(K.sessions,[]).find(x=>x.id===sid);if(!s)return;
 sessionId=s.id;examId=s.examId||s.id;examName=s.name;questions=s.questions;answers=s.answers||Array(questions.length).fill(null);reviews=new Set(s.reviews||[]);checkedQuestions=new Set(s.checkedQuestions||[]);matchOrders=s.matchOrders||{};current=Math.min(s.current||0,questions.length-1);seconds=s.seconds===0?0:Math.min(60*60,Math.max(1,s.seconds||5*60));quizDurationMinutes=clampDurationMinutes(s.quizDurationMinutes||Math.ceil(Math.max(seconds,1)/60));timerState.examSeconds=Number.isFinite(s.examTimerSeconds)?s.examTimerSeconds:seconds;timerState.practiceSeconds=s.practiceTimerSeconds||5*60;timerState.running=!!s.practiceTimerRunning;examFinished=!!s.examFinished;mode=s.mode||settings.defaultMode;sections=s.sections||[];registerActiveExam();
 if(document.getElementById("examTitle"))document.getElementById("examTitle").textContent=examName;document.getElementById("headerQuizName").textContent=examName;showView("exam");render();toast("Session restored ✓")
}
function deleteSession(sid){put(K.sessions,get(K.sessions,[]).filter(x=>x.id!==sid));renderSessions();renderDashboard();renderHome();}


async function redirectQuestionToChatGPT(){
 const q=questions[current];if(!q){toast("No question loaded");return}
 const question=q.text||"";
 let source=`Question: ${question}`;
 if(Array.isArray(q.options)&&q.options.length)
   source+=`\nOptions: ${q.options.map((x,i)=>`${String.fromCharCode(65+i)}. ${x}`).join(" | ")}`;
 if(q.answer!==undefined)source+=`\nAnswer: ${typeof q.answer==="string"?q.answer:JSON.stringify(q.answer)}`;
 if(q.explanation)source+=`\nExplanation: ${q.explanation}`;
 if(q.hint)source+=`\nHint: ${q.hint}`;
 if(Array.isArray(q.pairs)&&q.pairs.length)
   source+=`\nPairs: ${q.pairs.map(p=>`${p.left} → ${p.right}`).join(" | ")}`;

 const template=fixedQuestionPrompt;
 if(!template){toast("Load seed-prompts.json in Settings first");return}
 const prompt=template.includes("{{question}}")
   ?template.split("{{question}}").join(source)
   :`${template}\n\nSource: ${source}`;

 const url="https://chatgpt.com/?q="+encodeURIComponent(prompt);
 const w=window.open(url,"_blank");
 if(!w)toast("Allow pop-ups to open ChatGPT");
}
function showGeneratedCBQs(cbqs){
 window.__generatedCBQs=cbqs;
 let modal=document.getElementById("cbqModal");
 if(!modal){modal=document.createElement("div");modal.id="cbqModal";modal.className="cbq-modal";document.body.appendChild(modal)}
 modal.innerHTML=`<div class="cbq-modal-card"><div class="cbq-modal-head"><div><div class="cbq-kicker"><svg class="ui-icon"><use href="#icon-brain"/></svg> CONCEPT REPAIR</div><h2>5 CBQs for this question</h2></div><button class="btn" onclick="closeCBQModal()">✕</button></div><div class="cbq-original">${esc(questions[current].text||"")}</div><div class="cbq-list">${cbqs.map((q,i)=>`<article class="generated-cbq"><div class="cbq-number">CBQ ${i+1}</div><div class="cbq-question">${esc(q.question||"")}</div><div class="cbq-options">${(q.options||[]).map((o,j)=>`<button class="cbq-option" onclick="answerGeneratedCBQ(this,${i},'${String.fromCharCode(65+j)}')"><span>${String.fromCharCode(65+j)}</span>${esc(o)}</button>`).join("")}</div><div class="cbq-feedback"></div><div class="cbq-explanation" style="display:none">${esc(q.explanation||"")}</div></article>`).join("")}</div><div class="cbq-modal-foot"><span>Work through all five, then return to the original question.</span><button class="btn primary" onclick="closeCBQModal()">↩ Reattempt Original</button></div></div>`;
 modal.style.display="flex";
 renderAllQuizMath(modal);
 modal.querySelectorAll(".cbq-question,.cbq-option,.cbq-explanation,.cbq-original").forEach(el=>renderAllQuizMath(el));
}
function answerGeneratedCBQ(btn,i,choice){
 const card=btn.closest(".generated-cbq"),q=window.__generatedCBQs?.[i];if(!q)return;
 card.querySelectorAll(".cbq-option").forEach(x=>x.disabled=true);
 const correct=String(q.answer).toUpperCase()===choice;btn.classList.add(correct?"correct":"wrong");
 const fb=card.querySelector(".cbq-feedback");fb.innerHTML=correct?"✓ Correct — continue to the next step.":"✕ Not quite. Review the explanation and continue.";fb.className="cbq-feedback "+(correct?"good":"bad");
 const ex=card.querySelector(".cbq-explanation");ex.style.display="block";renderAllQuizMath(ex);
}
function closeCBQModal(){const m=document.getElementById("cbqModal");if(m)m.remove();window.__generatedCBQs=null}



let lastResultSnapshot=null,resultFilter="all",lastTestStartedAt=0;

function hydrateResult(saved){
  const result={...saved};
  let source=Array.isArray(saved.questions)?saved.questions:null;
  if(!source&&saved.examId)source=getExamRecord(saved.examId)?.questions||null;
  if(!source&&saved.examId){
    const session=get(K.sessions,[]).find(x=>x.examId===saved.examId);
    source=session?.questions||null;
  }
  source=Array.isArray(source)?cloneData(source):[];
  const savedAnswers=Array.isArray(saved.answers)?saved.answers:[];
  const reviewIndices=new Set((Array.isArray(saved.reviews)?saved.reviews:[])
    .filter(index=>Number.isInteger(index)&&index>=0&&index<source.length));
  result.reviews=[...reviewIndices];
  result.questions=source.map((q,i)=>({...q,selected:savedAnswers[i]!==undefined?savedAnswers[i]:(q.selected??null),isReview:reviewIndices.has(i)}));
  return result;
}

function openSavedResult(resultId){
  const saved=get(K.results,[]).find(x=>x.id===resultId);if(!saved)return;
  openDetailedResults(saved);
}

function openDetailedResults(result){
 result=hydrateResult(result);
 lastResultSnapshot=result;
 resultFilter="all";
 document.querySelectorAll("#testResultsView .filter-btn").forEach(button=>button.classList.toggle("active",button.dataset.filter==="all"));
 const reviewCount=result.reviews.length;
 const practiceMarkedBtn=document.getElementById("practiceMarkedBtn");
 if(practiceMarkedBtn){
   practiceMarkedBtn.hidden=reviewCount===0;
   practiceMarkedBtn.textContent=`Practice marked (${reviewCount})`;
 }
 document.getElementById("resultSubtitle").textContent=`${result.name} · ${result.mode==="practice"?"Practice Mode":"Exam Mode"}`;
 document.getElementById("resultScore").textContent=Number(result.score).toFixed(result.score%1?1:0);
 document.getElementById("resultMax").textContent="/"+Number(result.max).toFixed(result.max%1?1:0);
 document.getElementById("resultPercent").textContent=result.percent.toFixed(1)+"%";
 document.getElementById("resultAttempted").textContent=result.correct+result.wrong;
 document.getElementById("resultCorrect").textContent=result.correct;
 document.getElementById("resultWrong").textContent=result.wrong;
 document.getElementById("resultSkipped").textContent=result.unanswered;
 const status=document.getElementById("resultStatus");
 const label=result.percent>=80?"🏆 Excellent":result.percent>=60?"✨ Good Progress":"💪 Needs Improvement";
 status.textContent=label;status.className="result-status"+(result.percent>=80?" good":"");
 document.getElementById("resultProgressBar").style.width=Math.min(100,Math.max(0,result.percent))+"%";
 document.getElementById("resultTime").textContent=`◷ Time taken: ${result.timeTaken||0}s`;
 renderResultSections(result);
 renderResultQuestions();
 const advice=result.percent>=80
   ?"Your fundamentals are working well. Focus on speed, edge cases and maintaining consistency."
   :result.percent>=60
   ?"You have a usable foundation. Review the questions you missed and convert each mistake into a small CBQ."
   :"Go back to concept breakdown. Practice the reasoning steps before attempting another timed test.";
 document.getElementById("resultInsight").textContent=advice;
 document.getElementById("resultNextStep").textContent=result.unanswered
   ?`You left ${result.unanswered} question${result.unanswered>1?"s":""} unanswered. Try completing every question in Practice Mode before the next timed attempt.`
   :"Retake this quiz after reviewing the explanations, then compare your score and accuracy.";
 showView("testResults");
}
function renderResultSections(result){
 const map={};
 result.questions.forEach(q=>{
   const s=q.section||"General";
   if(!map[s])map[s]={total:0,correct:0,wrong:0,skipped:0,marks:0,score:0};
   const x=map[s],selected=q.selected;
   x.total++;x.marks+=Number(q.marks||1);
   if(!answerIsPresent(selected,q))x.skipped++;
   else if(isQuestionCorrect(q,selected)){x.correct++;x.score+=Number(q.marks||1)}
   else{x.wrong++;x.score-=Number(q.negativeMarks||0)}
 });
 const el=document.getElementById("sectionPerformance");
 el.innerHTML=Object.entries(map).map(([name,x])=>{
   const pct=Math.max(0,Math.round(x.score/Math.max(x.marks,1)*100));
   return `<div style="margin-bottom:17px">
     <div class="perf-head"><div class="perf-title">${esc(name)}</div><div class="perf-score">+${x.correct} correct · ${x.wrong} wrong</div></div>
     <div class="perf-meta">Attempted: ${x.correct+x.wrong}/${x.total} · Accuracy: ${x.correct?Math.round(x.correct/Math.max(x.correct+x.wrong,1)*100):0}%</div>
     <div class="perf-bar ${pct>=60?"good":""}"><i style="width:${Math.min(100,pct)}%"></i></div>
     <div style="text-align:right;font-size:9px;color:var(--muted);margin-top:3px">${x.score.toFixed(x.score%1?1:0)}/${x.marks.toFixed(x.marks%1?1:0)}</div>
   </div>`;
 }).join("");
}

function setResultFilter(f){
 resultFilter=f;
 document.querySelectorAll("#testResultsView .filter-btn").forEach(b=>b.classList.toggle("active",b.dataset.filter===f));
 renderResultQuestions();
}
function moveResultQuestion(direction){
 const items=[...document.querySelectorAll("#resultQuestions .result-question")];
 if(!items.length)return;
 const active=document.querySelector("#resultQuestions .result-question.keyboard-current");
 let index=active?items.indexOf(active):(direction>0?-1:items.length);
 index=Math.max(0,Math.min(items.length-1,index+direction));
 items.forEach(item=>item.classList.remove("keyboard-current"));
 const target=items[index];
 target.classList.add("keyboard-current");
 target.scrollIntoView({behavior:"smooth",block:"center"});
}
function resultValueText(q,value){
 if(value==null)return "Not answered";
 if(q.type==="fill_blank")return String(value);
 if(q.type==="match"||q.type==="drag_drop"){
   const vals=Array.isArray(value)?value:[];
   return q.pairs.map((p,i)=>`${esc(p.left)} → ${esc(vals[i]??"")}`).join("<br>");
 }
 if(q.type==="ordering"){
   const vals=Array.isArray(value)?value:[];
   return vals.map((v,i)=>`${i+1}. ${esc(v)}`).join("<br>");
 }
 if(q.type==="image_choice"||q.type==="image"||q.type==="mcq"||q.type==="true_false"){
   const letter=String(value);
   if(/^[A-Z]$/.test(letter)){
     const idx=letter.charCodeAt(0)-65;
     return `${letter}. ${esc(q.options?.[idx]??"")}`;
   }
 }
 return esc(String(value));
}
function correctValueText(q){
 if(q.type==="fill_blank")return (q.acceptedAnswers||[q.answer]).map(esc).join(" / ");
 if(q.type==="match"||q.type==="drag_drop"){
   return q.pairs.map(p=>`${esc(p.left)} → ${esc(p.right)}`).join("<br>");
 }
 if(q.type==="ordering")return q.answer.map((v,i)=>`${i+1}. ${esc(v)}`).join("<br>");
 return resultValueText(q,q.answer);
}
function optionsHtml(q){
 if(q.type==="match"||q.type==="drag_drop"){
   return q.pairs.map(p=>`<div>${esc(p.left)} → ${esc(p.right)}</div>`).join("");
 }
 if(q.type==="ordering"){
   return q.options.map((o,i)=>`${i+1}. ${esc(o)}`).join("<br>");
 }
 if(q.type==="fill_blank")return `<div>Accepted: ${correctValueText(q)}</div>`;
 return (q.options||[]).map((o,i)=>`${String.fromCharCode(65+i)}. ${esc(o)}`).join("<br>");
}
function renderResultQuestions(){
 if(!lastResultSnapshot)return;
 const result=lastResultSnapshot,select=document.getElementById("resultSectionFilter");
 const names=[...new Set(result.questions.map(q=>q.section||"General"))];
 const current=select.value;
 select.innerHTML='<option>All Sections</option>'+names.map(n=>`<option>${esc(n)}</option>`).join("");
 if(names.includes(current))select.value=current;
 const section=select.value;
 const qs=result.questions.map((q,i)=>({...q,index:i})).filter(q=>{
   const selected=q.selected;
   const status=!answerIsPresent(selected,q)?"skipped":isQuestionCorrect(q,selected)?"correct":"wrong";
   const isReview=!!q.isReview;
   return (resultFilter==="all"||resultFilter==="review"&&isReview||status===resultFilter)&&(section==="All Sections"||q.section===section);
 });
 document.getElementById("reviewShown").textContent=`(${qs.length} shown)`;
 const el=document.getElementById("resultQuestions");
 el.innerHTML=qs.length?qs.map(q=>{
   const status=!answerIsPresent(q.selected,q)?"skip":isQuestionCorrect(q,q.selected)?"correct":"wrong";
   const isReview=!!q.isReview;
   const selected=resultValueText(q,q.selected);
   const correct=correctValueText(q);
   return `<div class="result-question ${status}" onclick="this.classList.toggle('open')">
     <div class="result-qno">${q.index+1}</div>
     <div>
       <div class="result-qmeta">SECTION ${esc(q.section||"GENERAL")} <span style="margin-left:5px">· ${status==="correct"?"✓ Correct +"+q.marks:status==="wrong"?"× Wrong":"Skipped"}</span>${isReview?'<span class="result-mark" aria-label="Marked for review">⚑ Marked for review</span>':""}</div>
       <div class="result-qtext">${esc(q.text)}</div>
       <div class="result-review-meta">Type: <strong>${esc(q.type||"mcq")}</strong> Â· Marks: <strong>${status==="correct"?"+"+Number(q.marks||0):status==="wrong"?"-"+Number(q.negativeMarks||0):"0"}</strong></div>
       <div class="result-answer">Your answer: <strong>${selected}</strong>${status!=="correct"?` · Correct: <strong>${correct}</strong>`:""}</div>
       <div class="result-detail">
         ${q.image?`<img class="result-question-image" src="${esc(q.image)}" alt="Question image">`:""}
         <strong>Options / Items</strong>
         <div style="margin-top:5px">${optionsHtml(q)}</div>
         ${q.explanation?`<div class="result-explanation"><strong><svg class="ui-icon"><use href="#icon-lightbulb"/></svg> Explanation</strong><br>${esc(q.explanation)}</div>`:""}
       </div>
     </div>
     <div class="result-status-icon">${status==="correct"?"✓":status==="wrong"?"×":"−"}</div>
   </div>`;
 }).join(""):'<div class="empty">No questions match this filter.</div>';
 renderAllQuizMath(el);
}

function practiceMarkedQuestions(){
 if(!lastResultSnapshot)return;
 const marked=[...new Set(lastResultSnapshot.reviews||[])]
   .filter(index=>Number.isInteger(index)&&index>=0&&index<lastResultSnapshot.questions.length)
   .sort((a,b)=>a-b);
 if(!marked.length){toast("No questions are marked for review");return}
 questions=marked.map(index=>{
   const question=cloneData(lastResultSnapshot.questions[index]);
   delete question.selected;
   return question;
 });
 answers=Array(questions.length).fill(null);
 reviews=new Set(questions.map((_,index)=>index));
 checkedQuestions=new Set();
 matchOrders={};
 sections=[...new Set(questions.map(question=>question.section||"General"))].map(name=>({name}));
 current=0;
 examName=`${lastResultSnapshot.name} · Marked review`;
 examId=id();
 sessionId=null;
 mode="practice";
 examFinished=false;
 quizDurationMinutes=5;
 seconds=quizDurationMinutes*60;
 timerState.examSeconds=seconds;
 timerState.practiceSeconds=5*60;
 timerState.running=false;
 showView("exam");
 render();
 saveSession();
 toast(`Practice ready · ${questions.length} marked question${questions.length===1?"":"s"}`);
}

function saveResultCopy(){toast("Result is already saved locally ✓")}
function retakeLastTest(){
 if(!lastResultSnapshot)return;
 const qs=lastResultSnapshot.questions;
 questions=qs.map(q=>({
   type:q.type,text:q.text,options:q.options||[],answer:q.answer,
   acceptedAnswers:q.acceptedAnswers||[],pairs:q.pairs||[],image:q.image||"",
   explanation:q.explanation||"",marks:q.marks,negativeMarks:q.negativeMarks,section:q.section
 }));
 answers=Array(questions.length).fill(null);reviews=new Set();checkedQuestions=new Set();matchOrders={};current=0;
 seconds=clampDurationMinutes(lastResultSnapshot.durationMinutes||settings.defaultDuration||5)*60;
 quizDurationMinutes=clampDurationMinutes(lastResultSnapshot.durationMinutes||settings.defaultDuration||5);
 sessionId=null;examName=lastResultSnapshot.name;mode=lastResultSnapshot.mode||settings.defaultMode;examFinished=false;examId=lastResultSnapshot.examId||id();
 timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;
 registerActiveExam({name:examName});
 if(document.getElementById("examTitle"))document.getElementById("examTitle").textContent=examName;document.getElementById("headerQuizName").textContent=examName;
 showView("exam");render();saveSession();toast("Retake ready ✓")
}
function saveResult(){
 let correct=0,wrong=0,unanswered=0,score=0,max=0;
 questions.forEach((q,i)=>{max+=Number(q.marks||1);if(!answerIsPresent(answers[i],q))unanswered++;else if(isQuestionCorrect(q,answers[i])){correct++;score+=Number(q.marks||1)}else{wrong++;score-=Number(q.negativeMarks||0)}});
 const percent=Math.max(0,Math.round(score/Math.max(max,1)*100)),timestamp=new Date().toISOString(),r={
  id:id(),name:examName,mode,date:timestamp,timestamp,total:questions.length,
  correct,wrong,unanswered,score,max,percent,durationMinutes:quizDurationMinutes,
  timeTaken:Math.max(0,(quizDurationMinutes*60)-seconds),
  examId:examId||null,
  questions:cloneData(questions),
  answers:cloneData(answers),
  matchOrders:cloneData(matchOrders),
  reviews:[...reviews],
  checkedQuestions:[...checkedQuestions]
 };
 if(!examId)registerActiveExam();
 r.examId=examId;
 const rs=get(K.results,[]);rs.unshift(r);put(K.results,rs);backupToPersistentStorage();return r
}
function renderStackedRows(items,renderRow,emptyMessage){
 const list=Array.isArray(items)?items:[];
 if(!list.length)return `<div class="empty">${emptyMessage}</div>`;
 const columns=[];
 for(let i=0;i<list.length;i+=10)columns.push(list.slice(i,i+10));
 return `<div class="stacked-list">${columns.map(column=>`<div class="stack-column">${column.map(renderRow).join("")}</div>`).join("")}</div>`;
}
function renderContinueStudying(sessions){return renderStudyWorkspace(sessions)}
function planSortNewestFirst(a,b){
 const created=String(b.createdAt||"").localeCompare(String(a.createdAt||""));
 if(created)return created;
 return (String(b.date||"")+" "+String(b.time||"")).localeCompare(String(a.date||"")+" "+String(a.time||""));
}
function renderDashboard(){
 renderRecentQuizzes();
 const recent=get(K.recent,[]);
 const openedAtFor=session=>{
  const recentItem=recent.find(item=>item.id===(session.examId||session.id));
  return recentItem?.lastOpenedAt||session.updatedAt||session.createdAt||"";
 };
 const ss=get(K.sessions,[]).slice().sort((a,b)=>String(openedAtFor(b)).localeCompare(String(openedAtFor(a))));
 const ssl = document.getElementById("homeSessionsList");
 if(ssl)ssl.innerHTML=renderContinueStudying(ss,openedAtFor);
 const rs=get(K.results,[]),avg=rs.length?Math.round(rs.reduce((a,r)=>a+r.percent,0)/rs.length):0,best=rs.length?Math.max(...rs.map(r=>r.percent)):0;
 const attempted=rs.reduce((a,r)=>a+(Number(r.correct)||0)+(Number(r.wrong)||0),0),solved=rs.reduce((a,r)=>a+(Number(r.correct)||0),0);
 document.getElementById("mTests").textContent=rs.length;document.getElementById("mAvg").textContent=avg+"%";document.getElementById("mBest").textContent=best+"%";document.getElementById("mQuestions").textContent=attempted;
 document.getElementById("mSolved").textContent=solved;
 document.getElementById("resultsList").innerHTML=rs.length?rs.slice(0,15).map(r=>`<div class="resultrow"><div class="resultmain"><strong>${esc(r.name)}</strong><small>${new Date(r.date).toLocaleString()} · ${r.mode==="practice"?"Practice":"Exam"} · ${r.correct}/${r.total} correct</small></div><div style="display:flex;align-items:center;gap:10px;"><b class="${r.percent>=80?"good":r.percent>=50?"mid":"bad"}">${r.percent}%</b><button class="session-delete" onclick="deleteResult('${r.id}')">×</button></div></div>`).join(""):'<div class="empty">No results yet.</div>';
 document.querySelectorAll("#resultsList .resultrow").forEach((row,i)=>{
   const result=rs[i];if(!result)return;
   row.classList.add("result-history-item");
   row.addEventListener("click",()=>openSavedResult(result.id));
   row.querySelectorAll(".session-delete").forEach(button=>button.addEventListener("click",event=>event.stopPropagation()));
 });
}
function deleteResult(id) {
  const rs = get(K.results, []);
  put(K.results, rs.filter(r => r.id !== id));
  renderDashboard();
  toast("Result deleted ✓");
}
function setGoalPreset(target){
 document.getElementById("goalTarget").value=target;
 if(!document.getElementById("goalInput").value.trim())document.getElementById("goalInput").value=`Reach ${target}% average in CBQ practice`;

}
function saveGoal(){
 const text=document.getElementById("goalInput").value.trim()||"Improve my CBQ performance";
 const target=Math.max(1,Math.min(100,Number(document.getElementById("goalTarget").value||80)));
 put(K.goal,{text,target,updatedAt:new Date().toISOString()});renderGoal();toast("Goal saved ✓")
}
function renderGoal(){
 const g=get(K.goal,{}),rs=get(K.results,[]),avg=rs.length?Math.round(rs.reduce((a,r)=>a+r.percent,0)/rs.length):0,target=Number(g.target||80),progress=Math.min(100,Math.round(avg/target*100));
 document.getElementById("goalInput").value=g.text||"";
 document.getElementById("goalTarget").value=target;
 document.getElementById("goalLabel").textContent=g.text?`${avg}% average · target ${target}%`:"Set a goal to track progress";
 document.getElementById("goalPercent").textContent=g.text?`${progress}% of goal`:"0%";
 document.getElementById("goalBar").style.width=(g.text?progress:0)+"%";
 document.querySelectorAll(".milestone").forEach(x=>x.classList.toggle("active",Number(x.textContent.match(/\d+/)?.[0])===target));
}
function clearResults(){if(confirm("Delete all saved results?")){localStorage.removeItem(K.results);renderDashboard();toast("Results cleared")}}


function planDateFromSource(source){
  const raw=source.examDate||source.scheduledDate||source.plannedDate||source.date||source.testDate;
  if(raw && /^\d{4}-\d{2}-\d{2}$/.test(String(raw))) return String(raw);
  const d=new Date();d.setDate(d.getDate()+7);
  return d.toISOString().slice(0,10);
}
function planTimeFromSource(source){
  const raw=source.time||source.examTime||source.scheduledTime;
  return raw ? String(raw).slice(0,5) : "";
}
function clearQuickPlan(){
  const box=document.getElementById("planJson"),status=document.getElementById("planJsonStatus");
  if(box)box.value="";
  if(status){
    status.textContent="Paste → Plan Test · Ctrl/Cmd+Enter";
    status.style.color="";
  }
  box?.focus();
}
function saveQuickPlan(){
  const box=document.getElementById("planJson"),status=document.getElementById("planJsonStatus");
  const raw=box?.value.trim();
  if(!raw){toast("Paste quiz JSON first");return}
  try{
    const source=parseQuizInput(raw);
    const quizSource=source.quiz||source.exam||source;
    const q=parseQuiz(quizSource);
    const name=source.name||q.name||"Planned CBQ";
    const date=planDateFromSource(source);
    const time=planTimeFromSource(source);
    const ps=get(K.plans,[]);
    ps.push({id:id(),name,date,time,notes:"",json:JSON.stringify(quizSource),createdAt:new Date().toISOString()});
    ps.sort(planSortNewestFirst);
    put(K.plans,ps);
    box.value="";
    if(status){status.textContent=`✓ Planned: ${name} · ${date}`;status.style.color="var(--good)"}
    renderPlans();renderHome();toast("Test planned ✓");
  }catch(e){
    if(status){status.textContent="✕ "+e.message+" Common paste formatting is supported."; status.style.color="var(--bad)"}
    toast("Invalid quiz JSON");
  }
}

function savePlan(){
 const name=document.getElementById("planName").value.trim(),date=document.getElementById("planDate").value,time=document.getElementById("planTime").value,notes=document.getElementById("planNotes").value.trim(),raw=document.getElementById("planJson").value.trim();
 if(!name||!date){toast("Add a test name and date");return}
 let json="";
 if(raw){
   try{
     const source=JSON.parse(raw);
     parseQuiz(source); // validate now, but keep the original compatible schema
     json=JSON.stringify(source);
   }catch(e){toast("Invalid quiz JSON: "+e.message);return}
 }
 const ps=get(K.plans,[]);ps.push({id:id(),name,date,time,notes,json,createdAt:new Date().toISOString()});ps.sort(planSortNewestFirst);put(K.plans,ps);
 ["planName","planDate","planTime","planNotes","planJson"].forEach(x=>document.getElementById(x).value="");renderPlans();toast("Future test saved ✓")
}
function renderPlans(){
 const ps=get(K.plans,[]).slice().sort(planSortNewestFirst),el=document.getElementById("plansList");
 const pc=document.getElementById("plannerCount");if(pc)pc.textContent=String(ps.length);
 el.innerHTML=renderStackedRows(ps,p=>`<div class="planrow"><div class="planmain"><strong>${esc(p.name)}</strong><small>${p.date}${p.time?" · "+p.time:""}${p.notes?" · "+esc(p.notes):""}</small></div><div style="display:flex;gap:5px"><button class="btn primary" onclick="startPlan('${p.id}')">▶ Start</button><button class="btn" onclick="deletePlan('${p.id}')">×</button></div></div>`,`No upcoming tests.`);
}
function startPlan(pid){
 const p=get(K.plans,[]).find(x=>x.id===pid);if(!p)return;if(!p.json){toast("No quiz JSON attached to this plan");return}
 const q=parseQuiz(JSON.parse(p.json));questions=prepareShuffledQuiz(q.questions);sections=q.sections;examName=q.name||p.name;examId=p.examId||p.id;quizDurationMinutes=clampDurationMinutes(q.durationMinutes,settings.defaultDuration||5);answers=Array(questions.length).fill(null);reviews=new Set();checkedQuestions=new Set();matchOrders={};current=0;seconds=quizDurationMinutes*60;timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;sessionId=null;mode=settings.defaultMode;examFinished=false;
 registerActiveExam({source:"planned",plannedDate:p.date,plannedTime:p.time,name:p.name});
 if(document.getElementById("examTitle"))document.getElementById("examTitle").textContent=examName;document.getElementById("headerQuizName").textContent=examName;showView("exam");render();setTimeout(applyQuestionSidebarState,50);saveSession();toast("Planned test loaded ✓")
}
function deletePlan(pid){put(K.plans,get(K.plans,[]).filter(x=>x.id!==pid));renderPlans()}
async function importDataFile(event){
  const file=event.target.files?.[0];
  const status=document.getElementById("dataImportStatus");
  if(!file)return;
  try{
    const raw=await file.text();
    const parsed=JSON.parse(raw);

    // Accept only an ExamFlow backup structure. Quiz JSON belongs in
    // "Add CBQ Quiz" and is intentionally not mixed with application backup.
    const allowed=["settings","results","goal","plans","sessions","exams","recent","study"];
    const hasBackup=allowed.some(k=>Object.prototype.hasOwnProperty.call(parsed,k));
    if(!hasBackup)throw new Error("This is a quiz JSON, not an ExamFlow data backup. Use Add CBQ Quiz.");

    const overwrite=confirm(
      "Import this ExamFlow backup?\\n\\n" +
      "This will replace your current settings, results, goals, plans, saved sessions and quiz history with the backup."
    );
    if(!overwrite){
      event.target.value="";
      return;
    }

    if(parsed.settings!==undefined)put(K.settings,parsed.settings);
    if(parsed.results!==undefined)put(K.results,Array.isArray(parsed.results)?parsed.results:[]);
    if(parsed.goal!==undefined)put(K.goal,parsed.goal||{});
    if(parsed.plans!==undefined)put(K.plans,Array.isArray(parsed.plans)?parsed.plans:[]);
    if(parsed.sessions!==undefined)put(K.sessions,Array.isArray(parsed.sessions)?parsed.sessions:[]);
    if(parsed.study!==undefined)put(K.study,Array.isArray(parsed.study)?parsed.study:[]);
    if(parsed.exams!==undefined)put(K.exams,Array.isArray(parsed.exams)?parsed.exams:[]);
    if(parsed.recent!==undefined)put(K.recent,Array.isArray(parsed.recent)?parsed.recent:[]);
    if(parsed.examDeadline!==undefined){
      if(parsed.examDeadline)localStorage.setItem("examflow_exam_deadline",String(parsed.examDeadline));
      else localStorage.removeItem("examflow_exam_deadline");
    }

    settings=loadSettings();
    renderSessions();renderDashboard();renderPlans();renderHome();renderTodos();applySettings();
    await savePersistentBackup();
    if(status){
      status.hidden=false;
      status.textContent="✓ Backup imported successfully.";
      status.style.color="var(--good)";
    }
    toast("ExamFlow data imported ✓");
  }catch(err){
    if(status){
      status.hidden=false;
      status.textContent="✕ "+(err?.message||"Could not import this JSON.");
      status.style.color="var(--bad)";
    }
    toast("Import failed");
  }finally{
    event.target.value="";
  }
}

function exportData(){
 const data={study:get(K.study,[]),settings,results:get(K.results,[]),goal:get(K.goal,{}),plans:get(K.plans,[]),sessions:get(K.sessions,[]),exams:get(K.exams,[]),recent:get(K.recent,[])},a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="examflow-data.json";a.click()
}
function resetData(){if(confirm("Reset all local ExamFlow data?")){Object.values(K).forEach(x=>localStorage.removeItem(x));location.reload()}}



async function pasteFromClipboard(targetId,statusId,buttonId){
  const target=document.getElementById(targetId);
  const status=document.getElementById(statusId);
  const btn=document.getElementById(buttonId);
  if(!target)return;
  const original=btn?btn.innerHTML:'<svg class="ui-icon"><use href="#icon-copy"/></svg>Paste from Clipboard';
  try{
    if(btn){btn.disabled=true;btn.innerHTML='<svg class="ui-icon"><use href="#icon-clock"/></svg>Reading…';}
    if(!window.isSecureContext || !navigator.clipboard || !navigator.clipboard.readText){
      throw new Error("secure clipboard unavailable");
    }
    const text=await navigator.clipboard.readText();
    if(!text || !text.trim()){
      if(status){status.textContent="Clipboard is empty.";status.style.color="var(--bad)";}
      return;
    }
    target.value=text;
    target.dispatchEvent(new Event("input",{bubbles:true}));
    if(status){
      status.textContent="✓ Pasted directly from clipboard.";
      status.style.color="var(--good)";
    }
    target.focus();
    toast("JSON pasted ✓");
  }catch(err){
    if(status){
      status.textContent="Clipboard access was blocked. Allow clipboard permission for this site, then click Paste again.";
      status.style.color="var(--bad)";
    }
    toast("Clipboard permission blocked");
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML=original;}
  }
}


/* Final exam date countdown */
function saveExamDeadline(sourceId="planExamDeadlineInput"){
  const v=document.getElementById(sourceId)?.value;
  if(!v){toast("Choose your final exam date");return}
  localStorage.setItem("examflow_exam_deadline",v);
  renderExamDeadline();
  toast("Final exam date saved ✓");
}
function getSavedExamDeadline(){return localStorage.getItem("examflow_exam_deadline")||""}
function setDeadlineInputValue(v){
  ["planExamDeadlineInput"].forEach(id=>{
    const input=document.getElementById(id);if(input)input.value=v;
  });
}
function openDeadlinePicker(idValue){
  const input=document.getElementById(idValue);
  if(!input)return;
  if(typeof input.showPicker==="function")input.showPicker();else input.click();
}
function renderExamDeadline(){
  const v=getSavedExamDeadline();
  const targets=[
    [document.getElementById("planExamCountdown"),document.getElementById("planExamDate")]
  ];
  setDeadlineInputValue(v);
  if(!v){
    targets.forEach(([count,date])=>{
      if(count)count.textContent="No exam date set";
      if(date)date.textContent="Choose a target date to start your countdown.";
    });
    return;
  }
  const parts=v.split("-").map(Number),targetUtc=Date.UTC(parts[0],parts[1]-1,parts[2]);
  const now=new Date(),todayUtc=Date.UTC(now.getFullYear(),now.getMonth(),now.getDate());
  const days=Math.round((targetUtc-todayUtc)/86400000);
  const target=new Date(targetUtc),dateText=target.toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric",timeZone:"UTC"});
  const text=days<0?"Exam date passed":days===0?"Exam day":`${days} day${days===1?"":"s"} remaining`;
  targets.forEach(([count,date])=>{
    if(count)count.textContent=text;
    if(date)date.textContent=days<0?`Target was ${dateText}`:`Target: ${dateText}`;
  });
}
if(!window.examflowDeadlineInterval)window.examflowDeadlineInterval=setInterval(renderExamDeadline,30000);

/* Question progress drawer */

const QUESTION_SIDEBAR_KEY="examflow_question_sidebar_open";

function getQuestionSidebarState(){
  try{return localStorage.getItem(QUESTION_SIDEBAR_KEY)==="true"}catch{return false}
}
function setQuestionSidebarState(open){
  try{localStorage.setItem(QUESTION_SIDEBAR_KEY,open?"true":"false")}catch{}
}
function applyQuestionSidebarState(){
  const d=document.getElementById("examProgressDrawer");
  const b=document.querySelector(".exam-progress-backdrop");
  if(!d)return;
  const open=getQuestionSidebarState();
  d.classList.toggle("open",open);
  document.querySelector("#examView .main")?.classList.toggle("palette-open",open);
  d.setAttribute("aria-hidden",String(!open));
  d.inert=!open;
  document.getElementById("examProgressBtn")?.setAttribute("aria-expanded",String(open));
  if(b)b.classList.toggle("open",open);
  if(b)b.setAttribute("aria-hidden",String(!open));
  if(open)renderQuestionProgress();
}

function toggleQuestionProgress(){
  const d=document.getElementById("examProgressDrawer");
  const b=document.querySelector(".exam-progress-backdrop");
  if(!d)return;
  const open=!d.classList.contains("open");
  setQuestionSidebarState(open);
  d.classList.toggle("open",open);
  document.querySelector("#examView .main")?.classList.toggle("palette-open",open);
  d.setAttribute("aria-hidden",String(!open));
  if(!open&&d.contains(document.activeElement))document.getElementById("examProgressBtn")?.focus({preventScroll:true});
  d.inert=!open;
  document.getElementById("examProgressBtn")?.setAttribute("aria-expanded",String(open));
  if(b)b.classList.toggle("open",open);
  if(b)b.setAttribute("aria-hidden",String(!open));
  if(open)renderQuestionProgress();
}
function renderQuestionProgress(){
  const grid=document.getElementById("examProgressGrid");
  if(!grid||!questions.length||!document.getElementById("examProgressDrawer")?.classList.contains("open"))return;
  renderQuestionNavigation(grid,"progress-q",jumpToQuestion);
}


function shuffleAllQuestions(){
  if(!questions.length){
    toast("No questions to shuffle");
    return;
  }
  let indices = questions.map((_, i) => i);
  indices = shuffleArray(indices);
  const newQuestions = indices.map(i => questions[i]);
  const newAnswers = indices.map(i => answers[i]);
  const newReviews = new Set();
  reviews.forEach(oldIndex => {
    const newIndex = indices.indexOf(oldIndex);
    if (newIndex !== -1) newReviews.add(newIndex);
  });
  const newCheckedQuestions = new Set();
  checkedQuestions.forEach(oldIndex => {
    const newIndex = indices.indexOf(oldIndex);
    if (newIndex !== -1) newCheckedQuestions.add(newIndex);
  });
  const newMatchOrders = {};
  for(const [oldIdxStr, order] of Object.entries(matchOrders)) {
    const oldIndex = parseInt(oldIdxStr, 10);
    const newIndex = indices.indexOf(oldIndex);
    if(newIndex !== -1) newMatchOrders[newIndex] = order;
  }
  questions = newQuestions;
  answers = newAnswers;
  reviews = newReviews;
  checkedQuestions = newCheckedQuestions;
  matchOrders = newMatchOrders;
  current = 0;
  render();
  saveSessionSoon();
  toast("Questions shuffled ✓");
}

function _ignore_shuffleCurrentOptions(){
  const q=questions[current];
  if(!q || !Array.isArray(q.options) || q.options.length<2){
    toast("This question has no options to shuffle");
    return;
  }

  // Preserve the correct option by its value, then randomize the visible order.
  let correctValue=null;
  if(typeof q.answer==="string"){
    const m=q.answer.trim().match(/^([A-Z])$/i);
    if(m){
      const idx=m[1].toUpperCase().charCodeAt(0)-65;
      if(idx>=0 && idx<q.options.length) correctValue=q.options[idx];
    }else{
      correctValue=q.options.find(x=>String(x).trim()===q.answer.trim()) ?? null;
    }
  }else if(typeof q.answer==="number"){
    correctValue=q.options[q.answer] ?? null;
  }

  let shuffled=[...q.options];
  do{
    shuffled=shuffleArray(shuffled);
  }while(shuffled.length>1 && shuffled.every((x,i)=>String(x)===String(q.options[i])));

  q.options=shuffled;

  if(correctValue!==null){
    const newIndex=shuffled.findIndex(x=>String(x)===String(correctValue));
    if(newIndex>=0) q.answer=String.fromCharCode(65+newIndex);
  }

  // Keep the current selection intact if one exists, but reset checking because
  // the visual order has changed.
  checkedQuestions.delete(current);
  render();
  saveSessionSoon();
  toast("Options randomized ✓");
}

function jumpToQuestion(i){
  if(i<0||i>=questions.length)return;
  current=i;
  render();
  saveSessionSoon();
  if(window.innerWidth <= 800) {
    toggleQuestionProgress();
    window.scrollTo({top: 0, behavior: "smooth"});
  }
}


function shuffleArray(arr){
  const a=[...arr];
  for(let i=a.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}
function prepareShuffledQuiz(qs){
  return qs.map(q=>{
    const copy={...q};
    if(!Array.isArray(copy.options) || copy.options.length<2) return copy;

    // Preserve the actual correct option before shuffling.
    let correctIndex=-1;
    if(typeof copy.answer==="string"){
      const letter=copy.answer.trim().match(/^([A-Z])$/i);
      if(letter){
        correctIndex=letter[1].toUpperCase().charCodeAt(0)-65;
      }else{
        correctIndex=copy.options.findIndex(x=>String(x).trim()===copy.answer.trim());
      }
    }else if(typeof copy.answer==="number"){
      correctIndex=copy.answer;
    }

    const correctValue=correctIndex>=0 ? copy.options[correctIndex] : null;
    const shuffled=shuffleArray(copy.options);
    copy.options=shuffled;

    if(correctValue!==null){
      const newIndex=shuffled.findIndex(x=>String(x)===String(correctValue));
      if(newIndex>=0) copy.answer=String.fromCharCode(65+newIndex);
    }
    return copy;
  });
}

function startHomeQuiz(){
 const raw=document.getElementById("homeJson").value.trim();
 const status=document.getElementById("homeJsonStatus");
 if(!raw){status.textContent="Paste your CBQ JSON first.";status.style.color="var(--bad)";return}
 try{
   const parsed=parseQuiz(parseQuizInput(raw));
   questions=prepareShuffledQuiz(parsed.questions);sections=parsed.sections;examName=parsed.name;examId=id();
   quizDurationMinutes=clampDurationMinutes(parsed.durationMinutes,settings.defaultDuration||5);
   answers=Array(questions.length).fill(null);reviews=new Set();checkedQuestions=new Set();matchOrders={};current=0;seconds=quizDurationMinutes*60;timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;sessionId=null;mode=settings.defaultMode;examFinished=false;
   if(document.getElementById("examTitle"))document.getElementById("examTitle").textContent=examName;document.getElementById("headerQuizName").textContent=examName;
   if(document.getElementById("examMeta"))document.getElementById("examMeta").textContent=`${questions.length} questions · ${quizDurationMinutes} min · scoring from JSON`;
   registerActiveExam();saveSession();showView("exam");render();toast(`Ready — ${questions.length} questions ✓`);
 }catch(e){status.textContent="✕ "+e.message;status.style.color="var(--bad)"}
}
function pasteAndStart(){
 document.getElementById("homeJson").focus();
 document.getElementById("homeJson").scrollIntoView({behavior:"smooth",block:"center"});
}
function readHomeFile(e){
 const f=e.target.files[0];if(!f)return;
 const r=new FileReader();r.onload=()=>{document.getElementById("homeJson").value=r.result;document.getElementById("homeJsonStatus").textContent="JSON loaded — click Load & Start.";document.getElementById("homeJsonStatus").style.color="var(--good)"};r.readAsText(f)
}

function renderHome(){
 renderRecentQuizzes();
 const rs=get(K.results,[]),ss=get(K.sessions,[]),ps=get(K.plans,[]);
 const studyList=document.getElementById("homeSessionsList");
 if(studyList)studyList.innerHTML=renderContinueStudying(ss.slice().sort((a,b)=>String(b.updatedAt||"").localeCompare(String(a.updatedAt||""))));
 const avg=rs.length?Math.round(rs.reduce((a,r)=>a+r.percent,0)/rs.length):0,best=rs.length?Math.max(...rs.map(r=>r.percent)):0;
 const solved=rs.reduce((a,r)=>a+(Number(r.correct)||0),0);
 const homeMetrics={homeTests:rs.length,homeQuestions:solved};
 Object.entries(homeMetrics).forEach(([key,value])=>{const el=document.getElementById(key);if(el)el.textContent=value});
 const tip=rs.length?(rs[0].percent>=80?"You are in a strong rhythm. Try a timed Exam Mode session next.":rs[0].percent>=60?"Good momentum. Use Practice Mode on your weakest concepts.":"Slow down, break concepts into CBQs, then retest."): "Paste a CBQ below and begin a focused session.";
 const hst=document.getElementById("homeStudyTip"); if(hst) hst.textContent=tip;
 if(!document.getElementById("homePlansList"))return;

 document.getElementById("homePlansList").innerHTML=ps.length?ps.map(x=>`<div class="planrow"><div class="planmain"><strong>${esc(x.name)}</strong><small>${x.date}${x.time?" · "+x.time:""}</small></div><button class="btn" onclick="startPlan('${x.id}')">Start</button></div>`).join(""):'<div class="empty">No future tests planned.</div>';
}


function syncExamTitleBar(){
  const bar=document.getElementById("headerQuizName");
  const globalTitle=document.getElementById("globalExamTitle");
  if(examName){
    if(bar){bar.textContent=examName;bar.title=examName;}
    if(globalTitle){globalTitle.textContent=examName;globalTitle.title=examName;}
  }
}

function showView(name){
 closeMobileNav();
 if(name==="dashboard")name="home";
 if(name==="exam" && (!questions || questions.length===0)){
  toast("No quiz loaded. Please open a CBQ first.");
  name="home";
 }
 if(name==="exam"){updateTimerUI();updateModeUI();}
 document.body.classList.toggle("exam-active",name==="exam");
 window.scrollTo({top:0,behavior:"smooth"});
 ["home","exam","dashboard","testResults","planner","settings"].forEach(x=>document.getElementById(x+"View").classList.toggle("active",x===name));
 ["navHome","navExam","navPlanner","navSettings"].forEach(x=>document.getElementById(x).classList.remove("active"));
 const activeNav={home:"navHome",exam:"navExam",planner:"navPlanner",settings:"navSettings"}[name];
 if(activeNav)document.getElementById(activeNav).classList.add("active");
 if(name==="home"){renderHome();if(typeof renderTodos==='function')renderTodos();}if(name==="planner"){renderPlans();requestAnimationFrame(()=>{if(document.getElementById("plannerView")?.classList.contains("active"))renderPlannerCalendar()});renderPlannerTodos();renderExamDeadline();}if(name==="exam"){setTimeout(()=>{applyQuestionSidebarState();syncExamTitleBar()},0)}
 if(name==="settings"){const feedback=document.getElementById("instantFeedback");if(feedback)feedback.checked=!!settings.instantFeedback;
 const duration=document.getElementById("defaultDuration");if(duration)duration.value=String(settings.defaultDuration||30);
 renderPromptSettings();updateTheme();updateModeUI()}
}
function toggleMobileNav(){document.body.classList.toggle("mobile-nav-open")}
function closeMobileNav(){document.body.classList.remove("mobile-nav-open")}
function toast(s){const x=document.getElementById("toast");x.textContent=s;x.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>x.classList.remove("show"),2200)}


let examAudioCtx=null;
function ensureExamAudio(){
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return null;
    if(!examAudioCtx||examAudioCtx.state==="closed")examAudioCtx=new AC();
    if(examAudioCtx.state==="suspended")examAudioCtx.resume().catch(()=>{});
    return examAudioCtx;
  }catch(e){return null}
}
function playExamTone(frequency,duration,volume=0.07,when=0){
  const ctx=ensureExamAudio();
  if(!ctx)return false;
  try{
    const t=ctx.currentTime+when;
    const osc=ctx.createOscillator();
    const gain=ctx.createGain();
    osc.type="sine";
    osc.frequency.setValueAtTime(frequency,t);
    gain.gain.setValueAtTime(0.0001,t);
    gain.gain.exponentialRampToValueAtTime(volume,t+0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001,t+duration);
    osc.connect(gain);gain.connect(ctx.destination);
    osc.start(t);osc.stop(t+duration+0.03);
    return true;
  }catch(e){return false}
}
function playButtonSound(){
  if(settings.soundEnabled===false)return;
  playExamTone(523,.075,.065,0);
}
function playAnswerSound(correct){
  if(settings.soundEnabled===false)return;
  const ctx=ensureExamAudio();
  if(!ctx)return;
  if(correct){
    playExamTone(523,.16,.085,0);
    playExamTone(659,.18,.075,.14);
  }else{
    playExamTone(392,.14,.07,0);
    playExamTone(330,.17,.06,.13);
  }
}
function testAnswerSound(){
  if(settings.soundEnabled===false){
    toast("Enable interface sounds first");
    return;
  }
  const ok=playExamTone(523,.16,.085,0);
  playExamTone(659,.18,.075,.14);
  if(!ok)toast("This browser is blocking audio. Click the page once, then try again.");
}



function practiceCorrectAnswerHTML(q){
  const escv=v=>esc(String(v??""));
  if(q.type==="fill_blank"){
    return (q.acceptedAnswers||[q.answer]).map(escv).join(" / ");
  }
  if(q.type==="match"||q.type==="drag_drop"){
    return q.pairs.map((p,i)=>`<div class="answer-pair"><span>${i+1}.</span><span>${escv(p.left)}</span><span class="answer-arrow">→</span><span>${escv(p.right)}</span></div>`).join("");
  }
  if(q.type==="ordering"){
    return (q.answer||[]).map((v,i)=>`<div><strong>${i+1}.</strong> ${escv(v)}</div>`).join("");
  }
  if(q.type==="true_false")return escv(q.answer);
  if(q.options&&q.options.length){
    const idx=typeof q.answer==="number"?q.answer:
      (/^[A-Z]$/i.test(String(q.answer))?String(q.answer).toUpperCase().charCodeAt(0)-65:q.options.findIndex(o=>String(o)===String(q.answer)));
    if(idx>=0&&idx<q.options.length)return `${String.fromCharCode(65+idx)}. ${escv(q.options[idx])}`;
  }
  return escv(q.answer);
}

function viewPracticeAnswer(){
  if(mode!=="practice"||!questions.length)return;
  const q=questions[current];
  checkedQuestions.add(current);
  render();

  highlightCorrectAnswerForView(q);
  saveSessionSoon();
}
function showPracticeAnswerPanel(q){
  let panel=document.getElementById("practiceAnswerPanel");
  if(!panel){
    panel=document.createElement("div");panel.id="practiceAnswerPanel";panel.className="practice-answer-panel";
    document.getElementById("explanation").before(panel);
  }
  panel.dataset.question=String(current);
  panel.innerHTML=`<div class="answer-label"><span aria-hidden="true">✓</span> Correct answer</div><div class="answer-value quiz-rich-text">${practiceCorrectAnswerHTML(q)}</div>`;
  const correctIndex=getCorrectOptionIndex(q);
  if(correctIndex>=0&&q.type!=="ordering"){
    const value=panel.querySelector(".answer-value");value.replaceChildren();value.classList.add("answer-choice-value");
    const letter=document.createElement("span");letter.className="answer-option-letter";letter.textContent=String.fromCharCode(65+correctIndex);
    const text=document.createElement("div");setQuizRichText(text,q.options[correctIndex]);value.append(letter,text);
  }
  panel.style.display="block";renderAllQuizMath(panel);
}
function applyVerifiedAnswerStyles(q,chosen){
  const opts=document.getElementById("options"),correctIndex=getCorrectOptionIndex(q);
  opts.querySelectorAll(".option,[data-option-index]").forEach((button,i)=>{
    const index=button.hasAttribute("data-option-index")?Number(button.dataset.optionIndex):i;
    const isCorrect=index===correctIndex,isWrong=button.classList.contains("selected")&&!isCorrect;
    button.classList.toggle("answer-verified-correct",isCorrect);
    button.classList.toggle("answer-verified-wrong",isWrong);
    if(isCorrect||isWrong){const badge=document.createElement("span");badge.className="answer-state-badge";badge.textContent=isCorrect?"✓ Correct":"✕ Your answer";button.append(badge)}
  });
  if(answerIsPresent(chosen,q)){
    const correct=isQuestionCorrect(q,chosen);
    opts.querySelectorAll(".fill-answer,.order-item").forEach(el=>el.classList.add(correct?"answer-verified-correct":"answer-verified-wrong"));
  }
}
function clearVerifiedFeedback(){
  document.querySelectorAll("#options .answer-verified-correct,#options .answer-verified-wrong").forEach(el=>el.classList.remove("answer-verified-correct","answer-verified-wrong"));
  const feedback=document.getElementById("feedback");feedback.textContent="";feedback.removeAttribute("data-result");
  document.getElementById("explanation").style.display="none";
  const panel=document.getElementById("practiceAnswerPanel");if(panel)panel.style.display="none";
}
function getCorrectOptionIndex(q){
  if(!Array.isArray(q.options))return -1;
  if(typeof q.answer==="number")return q.answer;
  const a=String(q.answer??"").trim();
  if(/^[A-Z]$/i.test(a))return a.toUpperCase().charCodeAt(0)-65;
  return q.options.findIndex(x=>String(x).trim()===a);
}
function highlightCorrectAnswerForView(q){
  const opts=document.getElementById("options");
  if(!opts)return;
  opts.classList.add("answer-revealed");

  if(q.type==="match"||q.type==="drag_drop"){
    const rows=opts.querySelectorAll(".match-row");
    rows.forEach((row,i)=>{
      const pair=q.pairs?.[i];
      if(!pair)return;
      const trigger=row.querySelector(".match-trigger");
      if(trigger){
        trigger.classList.add("answer-correct-reveal");
        trigger.innerHTML=`<span class="match-selected">${esc(pair.right??"")}</span><span class="match-chevron">✓</span>`;
        renderAllQuizMath(trigger);
      }
      row.classList.add("match-correct");
    });
    return;
  }

  if(q.type==="ordering"){
    const list=opts.querySelector(".ordering-list");
    if(list&&Array.isArray(q.answer)){
      list.innerHTML="";
      q.answer.forEach((item,i)=>{
        const card=document.createElement("div");
        card.className="order-item order-answer-item answer-correct-reveal";
        card.setAttribute("role","listitem");
        const position=document.createElement("span");
        position.className="order-position";
        position.textContent=String(i+1);
        const content=document.createElement("div");
        content.className="order-content";
        setQuizRichText(content,String(item));
        card.append(position,content);
        list.appendChild(card);
      });
      renderAllQuizMath(list);
    }
    return;
  }

  if(q.type==="fill_blank"){
    const input=opts.querySelector(".fill-answer");
    if(input){
      input.value=String((q.acceptedAnswers||[q.answer])[0]??"");
      input.classList.remove("answer-verified-wrong");
      input.classList.add("answer-correct-reveal");
      input.readOnly=true;
      renderAllQuizMath(opts);
    }
    return;
  }

  // MCQ, True/False and Image Choice all use the option renderer.
  if(Array.isArray(q.options)){
    const correctIndex=getCorrectOptionIndex(q);
    opts.querySelectorAll(".option").forEach((b,i)=>{
      if(i===correctIndex)b.classList.add("correct","answer-correct-reveal");
      else if(!b.classList.contains("answer-verified-wrong"))b.classList.add("answer-not-correct");
    });
    // image_choice may use image cards instead of .option
    opts.querySelectorAll("[data-option-index]").forEach((b,i)=>{
      if(i===correctIndex)b.classList.add("correct","answer-correct-reveal");
      else if(!b.classList.contains("answer-verified-wrong"))b.classList.add("answer-not-correct");
    });
    renderAllQuizMath(opts);
  }
}

function checkCurrentAnswer(){
 if(!questions.length)return;
 const q=questions[current],chosen=answers[current];
 if(!answerIsPresent(chosen,q)){toast("Answer the question first");return}
 const wasChecked=checkedQuestions.has(current);
 checkedQuestions.add(current);
 if(!wasChecked&&mode==="practice")playAnswerSound(isQuestionCorrect(q,chosen));
 if(mode==="practice")render();
 else{
   const fb=document.getElementById("feedback");fb.textContent="✓ Answer recorded";fb.style.color="var(--muted)";fb.removeAttribute("data-result");
 }
 saveSessionSoon();
 flashKey("Enter");
}

function flashKey(key){
 const old=document.getElementById("keyboardFlash");
 if(old)old.remove();
 const el=document.createElement("div");
 el.id="keyboardFlash";
 el.textContent=key;
 el.style.cssText="position:fixed;left:50%;top:82px;transform:translateX(-50%);z-index:90;background:var(--text);color:var(--surface);padding:6px 10px;border-radius:8px;font:800 11px system-ui;opacity:.92;pointer-events:none";
 document.body.appendChild(el);
 setTimeout(()=>el.remove(),500);
}

setInterval(()=>{
  if(!timerState || !timerState.running || examFinished)return;
  if(mode==="practice"){
    // Practice timer logic removed, but keeping the block in case of future extensions
  }else{
    if(timerState.examSeconds>0){
      timerState.examSeconds=Math.max(0,timerState.examSeconds-1);
      seconds=timerState.examSeconds;
      updateTimerUI();
      if(timerState.examSeconds%10===0)saveSessionSoon();
      if(timerState.examSeconds<=0)finishTest(true);
    }
  }
},1000);

window.addEventListener("beforeunload",saveSession);

initPromptLibrary();applySettings();timerState.examSeconds=seconds;timerState.practiceSeconds=5*60;timerState.running=false;updateTimerUI();render();renderSessions();renderDashboard();renderPlans();renderHome();renderTodos();

initPersistentBackup();
